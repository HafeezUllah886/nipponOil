
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `accountID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `warehouseID` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accountNumber` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `initialBalance` double(8,2) unsigned DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`accountID`),
  KEY `accounts_warehouseid_foreign` (`warehouseID`),
  CONSTRAINT `accounts_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,1,'Walk-in Customer','customer',NULL,NULL,'00',NULL,NULL,NULL,NULL,NULL,'System','2023-12-27 12:12:44','2023-12-27 12:12:44'),(2,1,'Cash','business','cash',NULL,'01',NULL,NULL,NULL,NULL,NULL,'System','2023-12-27 12:12:44','2023-12-27 12:12:44'),(3,1,'ABC Bank','business','bank',NULL,'02',NULL,NULL,NULL,NULL,NULL,'System','2023-12-27 12:12:44','2023-12-27 12:12:44'),(4,1,'ABC Customer','customer',NULL,NULL,'04',NULL,NULL,NULL,NULL,NULL,'System','2023-12-27 12:12:44','2023-12-27 12:12:44'),(5,1,'ABC Supplier','supplier',NULL,'346','03',NULL,'03310070041','Nawan killi quetta','Hafeezullah886@gmail.com','asfadfds','System','2023-12-27 12:12:44','2023-12-29 08:57:30');
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `accounttransfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounttransfers` (
  `accountTransferID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `fromAccountID` bigint unsigned NOT NULL,
  `toAccountID` bigint unsigned NOT NULL,
  `amount` double(10,2) unsigned NOT NULL,
  `date` date NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refID` int NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`accountTransferID`),
  KEY `accounttransfers_fromaccountid_foreign` (`fromAccountID`),
  KEY `accounttransfers_toaccountid_foreign` (`toAccountID`),
  CONSTRAINT `accounttransfers_fromaccountid_foreign` FOREIGN KEY (`fromAccountID`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `accounttransfers_toaccountid_foreign` FOREIGN KEY (`toAccountID`) REFERENCES `accounts` (`accountID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `accounttransfers` WRITE;
/*!40000 ALTER TABLE `accounttransfers` DISABLE KEYS */;
INSERT INTO `accounttransfers` VALUES (1,2,5,5565655.00,'2023-12-29',NULL,4,'owner@email.com','2023-12-29 09:03:18','2023-12-29 09:03:18');
/*!40000 ALTER TABLE `accounttransfers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `advance_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `advance_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `empID` bigint unsigned NOT NULL,
  `advanceID` bigint unsigned NOT NULL,
  `accountID` bigint unsigned NOT NULL,
  `amount` double(10,2) unsigned NOT NULL,
  `date` date NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refID` int NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `advance_payments_empid_foreign` (`empID`),
  KEY `advance_payments_advanceid_foreign` (`advanceID`),
  KEY `advance_payments_accountid_foreign` (`accountID`),
  CONSTRAINT `advance_payments_accountid_foreign` FOREIGN KEY (`accountID`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `advance_payments_advanceid_foreign` FOREIGN KEY (`advanceID`) REFERENCES `advances` (`id`),
  CONSTRAINT `advance_payments_empid_foreign` FOREIGN KEY (`empID`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `advance_payments` WRITE;
/*!40000 ALTER TABLE `advance_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `advance_payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `advances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `advances` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `empID` bigint unsigned NOT NULL,
  `accountID` bigint unsigned NOT NULL,
  `date` date NOT NULL,
  `amount` bigint NOT NULL,
  `deduction` double(8,2) unsigned DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `refID` int NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `advances_empid_foreign` (`empID`),
  KEY `advances_accountid_foreign` (`accountID`),
  CONSTRAINT `advances_accountid_foreign` FOREIGN KEY (`accountID`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `advances_empid_foreign` FOREIGN KEY (`empID`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `advances` WRITE;
/*!40000 ALTER TABLE `advances` DISABLE KEYS */;
/*!40000 ALTER TABLE `advances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `attendances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendances` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `empID` bigint unsigned NOT NULL,
  `date` date NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `in` time DEFAULT NULL,
  `out` time DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `attendances_empid_foreign` (`empID`),
  CONSTRAINT `attendances_empid_foreign` FOREIGN KEY (`empID`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `attendances` WRITE;
/*!40000 ALTER TABLE `attendances` DISABLE KEYS */;
/*!40000 ALTER TABLE `attendances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brands` (
  `brandID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isActive` tinyint NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`brandID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (1,'Brand 1',0,'System','2023-12-27 12:12:44','2023-12-27 12:12:44'),(2,'Brand 2',0,'System','2023-12-27 12:12:44','2023-12-27 12:12:44');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `categoryID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentID` bigint unsigned DEFAULT NULL,
  `isActive` tinyint NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`categoryID`),
  KEY `categories_parentid_foreign` (`parentID`),
  CONSTRAINT `categories_parentid_foreign` FOREIGN KEY (`parentID`) REFERENCES `categories` (`categoryID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Category 1','Screenshot 2023-02-09 142113.png',NULL,0,'System','2023-12-27 12:12:44','2023-12-27 12:12:44'),(2,'Category 2','Screenshot 2023-02-09 142113.png',NULL,0,'System','2023-12-27 12:12:44','2023-12-27 12:12:44');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `display_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `display_messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `userID` bigint unsigned NOT NULL,
  `date` date NOT NULL,
  `msg` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `display_messages_userid_foreign` (`userID`),
  CONSTRAINT `display_messages_userid_foreign` FOREIGN KEY (`userID`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `display_messages` WRITE;
/*!40000 ALTER TABLE `display_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `display_messages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `emp_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `emp_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `empID` bigint unsigned NOT NULL,
  `date` date NOT NULL,
  `credit` double(10,2) unsigned DEFAULT NULL,
  `debt` double(10,2) unsigned DEFAULT NULL,
  `refID` int NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `emp_transactions_empid_foreign` (`empID`),
  CONSTRAINT `emp_transactions_empid_foreign` FOREIGN KEY (`empID`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `emp_transactions` WRITE;
/*!40000 ALTER TABLE `emp_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `emp_transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `salary` int DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `doe` date NOT NULL,
  `warehouseID` bigint unsigned NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employees_warehouseid_foreign` (`warehouseID`),
  CONSTRAINT `employees_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,'Owner','Owner','owner@email.com','03243243324','Active','Abc Quetta',100000,NULL,'2023-12-27',1,'System','2023-12-27 12:12:44','2023-12-27 12:12:44'),(2,'Admin','Admin','admin@email.com','03243243324','Active','Abc Quetta',50000,NULL,'2023-12-27',1,'System','2023-12-27 12:12:44','2023-12-27 12:12:44'),(3,'Cashier','Cashier','cashier@email.com','03243243324','Active','Abc Quetta',20000,NULL,'2023-12-27',1,'System','2023-12-27 12:12:44','2023-12-27 12:12:44');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `expensecategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expensecategories` (
  `expenseCategoryID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`expenseCategoryID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `expensecategories` WRITE;
/*!40000 ALTER TABLE `expensecategories` DISABLE KEYS */;
INSERT INTO `expensecategories` VALUES (1,'Misc','System','2023-12-27 12:12:52','2023-12-27 12:12:52');
/*!40000 ALTER TABLE `expensecategories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses` (
  `expenseID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `expenseCategoryID` bigint unsigned NOT NULL,
  `accountID` bigint unsigned NOT NULL,
  `warehouseID` bigint unsigned NOT NULL,
  `amount` double(10,2) unsigned NOT NULL,
  `date` date NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refID` int NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`expenseID`),
  KEY `expenses_expensecategoryid_foreign` (`expenseCategoryID`),
  KEY `expenses_accountid_foreign` (`accountID`),
  KEY `expenses_warehouseid_foreign` (`warehouseID`),
  CONSTRAINT `expenses_accountid_foreign` FOREIGN KEY (`accountID`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `expenses_expensecategoryid_foreign` FOREIGN KEY (`expenseCategoryID`) REFERENCES `expensecategories` (`expenseCategoryID`),
  CONSTRAINT `expenses_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
INSERT INTO `expenses` VALUES (1,1,2,1,243.00,'2023-12-29',NULL,5,'owner@email.com','2023-12-29 09:04:14','2023-12-29 09:04:14');
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fixed_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fixed_expenses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(8,2) NOT NULL,
  `warehouseID` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fixed_expenses_warehouseid_foreign` (`warehouseID`),
  CONSTRAINT `fixed_expenses_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fixed_expenses` WRITE;
/*!40000 ALTER TABLE `fixed_expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `fixed_expenses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_11_000000_create_warehouses_table',1),(2,'2014_10_12_000000_create_users_table',1),(3,'2014_10_12_100000_create_password_reset_tokens_table',1),(4,'2014_10_12_100000_create_password_resets_table',1),(5,'2019_08_19_000000_create_failed_jobs_table',1),(6,'2019_12_14_000001_create_personal_access_tokens_table',1),(7,'2023_06_19_083928_create_units_table',1),(8,'2023_06_19_095849_create_categories_table',1),(9,'2023_06_19_100239_create_brands_table',1),(10,'2023_06_19_101238_create_products_table',1),(11,'2023_06_19_110014_create_accounts_table',1),(12,'2023_06_19_110316_create_account_transfers_table',1),(13,'2023_06_19_110639_create_expense_categories_table',1),(14,'2023_06_19_110848_create_expenses_table',1),(15,'2023_06_19_113833_create_withdrawal_deposits_table',1),(16,'2023_06_19_120832_create_employees_table',1),(17,'2023_06_19_134008_create_purchase_statuses_table',1),(18,'2023_06_19_134245_create_purchases_table',1),(19,'2023_06_19_142823_create_purchase_payments_table',1),(20,'2023_06_20_064627_create_purchase_returns_table',1),(21,'2023_06_20_065102_create_purchase_return_details_table',1),(22,'2023_06_20_065553_create_references_table',1),(23,'2023_06_20_065725_create_sales_table',1),(24,'2023_06_20_070115_create_sale_orders_table',1),(25,'2023_06_20_073554_create_sale_payments_table',1),(26,'2023_06_20_080141_create_sale_returns_table',1),(27,'2023_06_20_082017_create_sale_return_details_table',1),(28,'2023_06_20_083212_create_stocks_table',1),(29,'2023_06_20_083623_create_transactions_table',1),(30,'2023_06_24_141850_create_purchase_orders_table',1),(31,'2023_07_17_101813_create_purchase_receives_table',1),(32,'2023_07_27_205731_create_permission_tables',1),(33,'2023_08_01_062704_create_sale_delivereds_table',1),(34,'2023_08_16_124253_create_purchase_return_payments_table',1),(35,'2023_08_22_064933_create_sale_return_payments_table',1),(36,'2023_10_08_164735_create_attendances_table',1),(37,'2023_10_09_124210_create_payrolls_table',1),(38,'2023_10_16_114155_create_emp_transactions_table',1),(39,'2023_10_20_063048_create_advances_table',1),(40,'2023_10_21_102819_create_advance_payments_table',1),(41,'2023_10_27_100654_create_stock_transfers_table',1),(42,'2023_10_27_101352_create_stock_transfer_details_table',1),(43,'2023_11_07_051313_create_display_messages_table',1),(44,'2023_11_07_161436_create_quotations_table',1),(45,'2023_11_07_161509_create_quotation_details_table',1),(46,'2023_11_09_072541_create_todos_table',1),(47,'2023_11_10_164126_create_notifications_table',1),(48,'2023_11_11_115018_create_visits_table',1),(49,'2023_11_12_073621_create_obsoletes_table',1),(50,'2023_11_13_180844_create_reconditioneds_table',1),(51,'2023_11_15_055318_create_fixed_expenses_table',1),(52,'2023_11_24_141434_create_repairs_table',1),(53,'2023_11_24_143608_create_repair_payments_table',1),(54,'2023_12_14_165007_create_product_prices_table',1),(55,'2023_12_23_074018_create_targets_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1),(2,'App\\Models\\User',2),(3,'App\\Models\\User',3);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `warehouseID` bigint unsigned NOT NULL,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_by` json DEFAULT NULL,
  `refID` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_warehouseid_foreign` (`warehouseID`),
  CONSTRAINT `notifications_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `obsoletes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `obsoletes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `productID` bigint unsigned NOT NULL,
  `warehouseID` bigint unsigned NOT NULL,
  `batchNumber` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `expiry` date DEFAULT NULL,
  `quantity` double(8,2) unsigned NOT NULL,
  `loss_amount` double(8,2) DEFAULT NULL,
  `recovery_amount` double(8,2) DEFAULT NULL,
  `net_loss` double(8,2) DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `refID` int NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `obsoletes_productid_foreign` (`productID`),
  KEY `obsoletes_warehouseid_foreign` (`warehouseID`),
  CONSTRAINT `obsoletes_productid_foreign` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`),
  CONSTRAINT `obsoletes_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `obsoletes` WRITE;
/*!40000 ALTER TABLE `obsoletes` DISABLE KEYS */;
INSERT INTO `obsoletes` VALUES (1,694,1,'def-2818','2023-12-27',NULL,1.00,700.00,400.00,300.00,'ytyutytyutuy',2,'owner@email.com','2023-12-27 12:13:40','2023-12-27 12:22:00');
/*!40000 ALTER TABLE `obsoletes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `payrolls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payrolls` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `empID` bigint unsigned NOT NULL,
  `accountID` bigint unsigned DEFAULT NULL,
  `genDate` date DEFAULT NULL,
  `issueDate` date DEFAULT NULL,
  `month` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salary` bigint unsigned NOT NULL,
  `commission` bigint unsigned DEFAULT NULL,
  `return_commission` bigint unsigned DEFAULT NULL,
  `fine` bigint unsigned DEFAULT NULL,
  `advance` bigint unsigned DEFAULT NULL,
  `adv_payment` bigint unsigned DEFAULT NULL,
  `adv_deduction_amount` bigint unsigned DEFAULT NULL,
  `adv_balance` bigint unsigned DEFAULT NULL,
  `adv_deduction` double(8,2) DEFAULT NULL,
  `workingDays` int DEFAULT NULL,
  `absenties` int DEFAULT NULL,
  `fineRate` int DEFAULT NULL,
  `sales` int DEFAULT NULL,
  `returns` int DEFAULT NULL,
  `netSalary` bigint DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refID` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payrolls_empid_foreign` (`empID`),
  KEY `payrolls_accountid_foreign` (`accountID`),
  CONSTRAINT `payrolls_accountid_foreign` FOREIGN KEY (`accountID`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `payrolls_empid_foreign` FOREIGN KEY (`empID`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `payrolls` WRITE;
/*!40000 ALTER TABLE `payrolls` DISABLE KEYS */;
/*!40000 ALTER TABLE `payrolls` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'View Users','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(2,'Add User','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(3,'Edit User','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(4,'Delete User','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(5,'View Owner Account','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(6,'View Admin Account','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(7,'View Permissions','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(8,'View User Permissions','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(9,'Assign Permissions To User','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(10,'Add Role','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(11,'View Roles','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(12,'Assign Role To User','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(13,'View Reports','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(14,'View Purchases','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(15,'Create Purchase','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(16,'Edit Purchase','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(17,'Delete Purchase','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(18,'Pay Purchase Payments','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(19,'Receive Purchase Products','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(20,'View Sales','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(21,'Create Sale','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(22,'Receive Sale Payments','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(23,'Edit Sale','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(24,'Delete Sale','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(25,'View Warehouses','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(26,'Add Warehouse','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(27,'Edit Warehouse','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(28,'Delete Warehouse','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(29,'View Units','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(30,'Add Unit','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(31,'Edit Unit','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(32,'Delete Unit','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(33,'View Products','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(34,'Add Products','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(35,'Edit Product','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(36,'Delete Product','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(37,'View Brands','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(38,'Edit Brand','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(39,'Delete Brand','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(40,'View Categories','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(41,'Edit Category','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(42,'Delete Category','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(43,'Create Accounts','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(44,'View Accounts','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(45,'Edit Account','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(46,'Delete Account','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(47,'View Deposit/Withdrawals','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(48,'Create Deposit/Withdrawals','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(49,'Delete Deposit/Withdrawals','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(50,'View Transfers','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(51,'Create Transfers','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(52,'Delete Transfers','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(53,'View Accounts Statement','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(54,'View Transfer','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(55,'Delete Transfer','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(56,'View Expenses','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(57,'Create Expense','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(58,'Delete Expense','web','2023-12-27 12:12:42','2023-12-27 12:12:42'),(59,'All Warehouses','web','2023-12-27 12:12:43','2023-12-27 12:12:43'),(60,'View Attendance','web','2023-12-27 12:12:43','2023-12-27 12:12:43'),(61,'Create Attendance','web','2023-12-27 12:12:43','2023-12-27 12:12:43'),(62,'Delete Attendance','web','2023-12-27 12:12:43','2023-12-27 12:12:43'),(63,'Edit Attendance','web','2023-12-27 12:12:43','2023-12-27 12:12:43'),(64,'View Payrolls','web','2023-12-27 12:12:43','2023-12-27 12:12:43'),(65,'Generate Payrolls','web','2023-12-27 12:12:43','2023-12-27 12:12:43'),(66,'Pay Salary','web','2023-12-27 12:12:43','2023-12-27 12:12:43'),(67,'Delete Payroll','web','2023-12-27 12:12:43','2023-12-27 12:12:43'),(68,'Create Employee Advances','web','2023-12-27 12:12:43','2023-12-27 12:12:43'),(69,'Edit Employee Advances','web','2023-12-27 12:12:43','2023-12-27 12:12:43'),(70,'Delete Employee Advances','web','2023-12-27 12:12:43','2023-12-27 12:12:43');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_prices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `productID` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_prices_productid_foreign` (`productID`),
  CONSTRAINT `product_prices_productid_foreign` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`)
) ENGINE=InnoDB AUTO_INCREMENT=701 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_prices` WRITE;
/*!40000 ALTER TABLE `product_prices` DISABLE KEYS */;
INSERT INTO `product_prices` VALUES (1,1,'Retail',6590.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(2,2,'Retail',1981.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(3,3,'Retail',5163.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(4,4,'Retail',7886.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(5,5,'Retail',7317.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(6,6,'Retail',3247.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(7,7,'Retail',3282.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(8,8,'Retail',2874.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(9,9,'Retail',9743.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(10,10,'Retail',3008.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(11,11,'Retail',6180.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(12,12,'Retail',1020.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(13,13,'Retail',9547.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(14,14,'Retail',8689.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(15,15,'Retail',3915.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(16,16,'Retail',8861.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(17,17,'Retail',5307.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(18,18,'Retail',9298.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(19,19,'Retail',719.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(20,20,'Retail',582.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(21,21,'Retail',8283.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(22,22,'Retail',3879.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(23,23,'Retail',5577.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(24,24,'Retail',3435.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(25,25,'Retail',8624.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(26,26,'Retail',5966.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(27,27,'Retail',9673.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(28,28,'Retail',8537.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(29,29,'Retail',7378.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(30,30,'Retail',5472.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(31,31,'Retail',6323.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(32,32,'Retail',1677.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(33,33,'Retail',7890.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(34,34,'Retail',4945.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(35,35,'Retail',7018.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(36,36,'Retail',2520.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(37,37,'Retail',3441.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(38,38,'Retail',1481.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(39,39,'Retail',7003.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(40,40,'Retail',748.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(41,41,'Retail',4573.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(42,42,'Retail',3935.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(43,43,'Retail',9262.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(44,44,'Retail',3808.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(45,45,'Retail',4914.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(46,46,'Retail',9746.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(47,47,'Retail',5488.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(48,48,'Retail',2202.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(49,49,'Retail',1251.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(50,50,'Retail',4973.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(51,51,'Retail',1697.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(52,52,'Retail',1219.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(53,53,'Retail',9518.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(54,54,'Retail',7870.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(55,55,'Retail',1823.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(56,56,'Retail',7977.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(57,57,'Retail',7389.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(58,58,'Retail',3235.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(59,59,'Retail',5539.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(60,60,'Retail',9348.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(61,61,'Retail',2278.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(62,62,'Retail',3495.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(63,63,'Retail',1141.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(64,64,'Retail',4005.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(65,65,'Retail',3432.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(66,66,'Retail',3019.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(67,67,'Retail',4923.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(68,68,'Retail',3464.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(69,69,'Retail',6234.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(70,70,'Retail',6128.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(71,71,'Retail',8057.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(72,72,'Retail',9427.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(73,73,'Retail',8799.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(74,74,'Retail',9203.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(75,75,'Retail',8757.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(76,76,'Retail',3640.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(77,77,'Retail',7200.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(78,78,'Retail',2460.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(79,79,'Retail',6164.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(80,80,'Retail',1278.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(81,81,'Retail',2224.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(82,82,'Retail',3805.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(83,83,'Retail',2455.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(84,84,'Retail',1572.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(85,85,'Retail',4512.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(86,86,'Retail',7624.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(87,87,'Retail',7726.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(88,88,'Retail',5044.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(89,89,'Retail',7509.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(90,90,'Retail',6261.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(91,91,'Retail',6147.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(92,92,'Retail',3247.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(93,93,'Retail',8616.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(94,94,'Retail',3839.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(95,95,'Retail',8923.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(96,96,'Retail',9115.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(97,97,'Retail',931.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(98,98,'Retail',9645.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(99,99,'Retail',868.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(100,100,'Retail',3522.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(101,101,'Retail',1952.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(102,102,'Retail',5427.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(103,103,'Retail',8774.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(104,104,'Retail',7596.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(105,105,'Retail',1229.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(106,106,'Retail',9509.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(107,107,'Retail',3528.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(108,108,'Retail',9345.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(109,109,'Retail',9426.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(110,110,'Retail',7710.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(111,111,'Retail',2624.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(112,112,'Retail',5351.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(113,113,'Retail',982.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(114,114,'Retail',8199.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(115,115,'Retail',8887.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(116,116,'Retail',9269.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(117,117,'Retail',2237.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(118,118,'Retail',4816.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(119,119,'Retail',4941.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(120,120,'Retail',7404.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(121,121,'Retail',8457.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(122,122,'Retail',6145.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(123,123,'Retail',3789.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(124,124,'Retail',2300.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(125,125,'Retail',3058.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(126,126,'Retail',704.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(127,127,'Retail',9442.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(128,128,'Retail',3268.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(129,129,'Retail',6564.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(130,130,'Retail',5587.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(131,131,'Retail',2998.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(132,132,'Retail',1887.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(133,133,'Retail',2507.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(134,134,'Retail',9976.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(135,135,'Retail',3184.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(136,136,'Retail',809.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(137,137,'Retail',2590.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(138,138,'Retail',6163.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(139,139,'Retail',4425.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(140,140,'Retail',1150.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(141,141,'Retail',2525.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(142,142,'Retail',8566.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(143,143,'Retail',2168.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(144,144,'Retail',9409.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(145,145,'Retail',7387.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(146,146,'Retail',2843.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(147,147,'Retail',4012.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(148,148,'Retail',6971.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(149,149,'Retail',5117.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(150,150,'Retail',5612.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(151,151,'Retail',4346.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(152,152,'Retail',3568.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(153,153,'Retail',9519.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(154,154,'Retail',3305.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(155,155,'Retail',2342.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(156,156,'Retail',7775.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(157,157,'Retail',4015.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(158,158,'Retail',7773.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(159,159,'Retail',9929.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(160,160,'Retail',8323.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(161,161,'Retail',6110.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(162,162,'Retail',5190.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(163,163,'Retail',9392.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(164,164,'Retail',8137.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(165,165,'Retail',8130.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(166,166,'Retail',6740.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(167,167,'Retail',2286.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(168,168,'Retail',1792.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(169,169,'Retail',6974.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(170,170,'Retail',3702.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(171,171,'Retail',8970.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(172,172,'Retail',3860.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(173,173,'Retail',6215.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(174,174,'Retail',4569.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(175,175,'Retail',8919.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(176,176,'Retail',6640.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(177,177,'Retail',9006.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(178,178,'Retail',2488.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(179,179,'Retail',2745.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(180,180,'Retail',959.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(181,181,'Retail',3678.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(182,182,'Retail',1154.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(183,183,'Retail',2377.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(184,184,'Retail',3230.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(185,185,'Retail',6724.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(186,186,'Retail',2019.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(187,187,'Retail',9687.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(188,188,'Retail',5876.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(189,189,'Retail',1566.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(190,190,'Retail',8209.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(191,191,'Retail',3417.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(192,192,'Retail',4985.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(193,193,'Retail',9241.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(194,194,'Retail',6452.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(195,195,'Retail',3442.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(196,196,'Retail',7103.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(197,197,'Retail',5994.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(198,198,'Retail',1290.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(199,199,'Retail',2071.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(200,200,'Retail',7681.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(201,201,'Retail',1369.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(202,202,'Retail',1047.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(203,203,'Retail',1917.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(204,204,'Retail',1750.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(205,205,'Retail',1838.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(206,206,'Retail',7841.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(207,207,'Retail',5234.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(208,208,'Retail',9337.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(209,209,'Retail',6404.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(210,210,'Retail',4403.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(211,211,'Retail',786.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(212,212,'Retail',579.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(213,213,'Retail',9789.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(214,214,'Retail',6514.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(215,215,'Retail',9374.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(216,216,'Retail',5879.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(217,217,'Retail',9289.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(218,218,'Retail',2366.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(219,219,'Retail',2307.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(220,220,'Retail',3290.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(221,221,'Retail',9892.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(222,222,'Retail',5254.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(223,223,'Retail',1229.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(224,224,'Retail',4073.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(225,225,'Retail',6113.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(226,226,'Retail',5414.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(227,227,'Retail',6330.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(228,228,'Retail',6786.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(229,229,'Retail',3975.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(230,230,'Retail',7716.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(231,231,'Retail',9766.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(232,232,'Retail',7939.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(233,233,'Retail',1167.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(234,234,'Retail',3492.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(235,235,'Retail',625.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(236,236,'Retail',6577.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(237,237,'Retail',8694.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(238,238,'Retail',2966.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(239,239,'Retail',9785.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(240,240,'Retail',550.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(241,241,'Retail',1037.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(242,242,'Retail',4072.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(243,243,'Retail',9214.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(244,244,'Retail',3679.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(245,245,'Retail',5287.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(246,246,'Retail',5230.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(247,247,'Retail',7954.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(248,248,'Retail',787.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(249,249,'Retail',4555.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(250,250,'Retail',3419.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(251,251,'Retail',9267.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(252,252,'Retail',5314.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(253,253,'Retail',1611.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(254,254,'Retail',1432.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(255,255,'Retail',7080.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(256,256,'Retail',9958.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(257,257,'Retail',2724.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(258,258,'Retail',5533.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(259,259,'Retail',6838.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(260,260,'Retail',1047.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(261,261,'Retail',2283.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(262,262,'Retail',3609.00,'2023-12-27 12:12:50','2023-12-27 12:12:50'),(263,263,'Retail',8762.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(264,264,'Retail',6153.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(265,265,'Retail',1991.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(266,266,'Retail',6161.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(267,267,'Retail',4313.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(268,268,'Retail',4023.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(269,269,'Retail',5516.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(270,270,'Retail',6292.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(271,271,'Retail',9588.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(272,272,'Retail',2535.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(273,273,'Retail',5044.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(274,274,'Retail',7547.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(275,275,'Retail',1072.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(276,276,'Retail',9093.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(277,277,'Retail',5587.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(278,278,'Retail',3446.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(279,279,'Retail',9632.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(280,280,'Retail',3607.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(281,281,'Retail',4224.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(282,282,'Retail',5705.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(283,283,'Retail',9280.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(284,284,'Retail',2137.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(285,285,'Retail',2998.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(286,286,'Retail',7155.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(287,287,'Retail',5621.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(288,288,'Retail',4419.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(289,289,'Retail',1416.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(290,290,'Retail',4419.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(291,291,'Retail',747.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(292,292,'Retail',3423.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(293,293,'Retail',6299.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(294,294,'Retail',4624.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(295,295,'Retail',8753.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(296,296,'Retail',6774.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(297,297,'Retail',8306.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(298,298,'Retail',9943.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(299,299,'Retail',7099.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(300,300,'Retail',7662.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(301,301,'Retail',6115.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(302,302,'Retail',2066.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(303,303,'Retail',7096.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(304,304,'Retail',9353.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(305,305,'Retail',9708.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(306,306,'Retail',2384.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(307,307,'Retail',1936.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(308,308,'Retail',6977.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(309,309,'Retail',9333.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(310,310,'Retail',4220.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(311,311,'Retail',5008.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(312,312,'Retail',6001.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(313,313,'Retail',5810.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(314,314,'Retail',5033.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(315,315,'Retail',4494.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(316,316,'Retail',3215.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(317,317,'Retail',2962.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(318,318,'Retail',4138.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(319,319,'Retail',856.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(320,320,'Retail',8582.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(321,321,'Retail',9045.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(322,322,'Retail',7674.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(323,323,'Retail',1653.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(324,324,'Retail',8066.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(325,325,'Retail',1919.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(326,326,'Retail',1288.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(327,327,'Retail',7367.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(328,328,'Retail',7065.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(329,329,'Retail',1003.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(330,330,'Retail',4614.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(331,331,'Retail',2766.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(332,332,'Retail',1685.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(333,333,'Retail',7623.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(334,334,'Retail',5460.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(335,335,'Retail',6810.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(336,336,'Retail',5187.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(337,337,'Retail',6751.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(338,338,'Retail',6291.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(339,339,'Retail',7639.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(340,340,'Retail',1103.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(341,341,'Retail',4330.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(342,342,'Retail',2308.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(343,343,'Retail',1921.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(344,344,'Retail',4786.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(345,345,'Retail',6747.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(346,346,'Retail',9562.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(347,347,'Retail',6479.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(348,348,'Retail',3335.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(349,349,'Retail',2851.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(350,350,'Retail',605.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(351,351,'Retail',5454.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(352,352,'Retail',2430.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(353,353,'Retail',8067.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(354,354,'Retail',6401.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(355,355,'Retail',4147.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(356,356,'Retail',5792.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(357,357,'Retail',1543.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(358,358,'Retail',5380.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(359,359,'Retail',1015.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(360,360,'Retail',3521.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(361,361,'Retail',6793.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(362,362,'Retail',2149.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(363,363,'Retail',9890.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(364,364,'Retail',1761.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(365,365,'Retail',4214.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(366,366,'Retail',1582.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(367,367,'Retail',2143.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(368,368,'Retail',9747.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(369,369,'Retail',1047.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(370,370,'Retail',7960.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(371,371,'Retail',8423.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(372,372,'Retail',5923.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(373,373,'Retail',7442.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(374,374,'Retail',860.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(375,375,'Retail',3077.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(376,376,'Retail',9929.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(377,377,'Retail',5641.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(378,378,'Retail',8944.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(379,379,'Retail',8801.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(380,380,'Retail',1595.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(381,381,'Retail',6009.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(382,382,'Retail',3729.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(383,383,'Retail',4919.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(384,384,'Retail',1970.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(385,385,'Retail',8014.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(386,386,'Retail',1693.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(387,387,'Retail',538.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(388,388,'Retail',3304.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(389,389,'Retail',1726.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(390,390,'Retail',5486.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(391,391,'Retail',6767.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(392,392,'Retail',5529.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(393,393,'Retail',7700.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(394,394,'Retail',4658.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(395,395,'Retail',4907.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(396,396,'Retail',6673.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(397,397,'Retail',5743.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(398,398,'Retail',630.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(399,399,'Retail',8647.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(400,400,'Retail',8168.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(401,401,'Retail',8584.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(402,402,'Retail',7149.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(403,403,'Retail',7213.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(404,404,'Retail',3292.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(405,405,'Retail',4739.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(406,406,'Retail',6140.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(407,407,'Retail',3454.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(408,408,'Retail',3602.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(409,409,'Retail',6869.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(410,410,'Retail',3254.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(411,411,'Retail',5410.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(412,412,'Retail',6001.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(413,413,'Retail',5712.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(414,414,'Retail',7111.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(415,415,'Retail',4446.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(416,416,'Retail',6037.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(417,417,'Retail',6462.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(418,418,'Retail',6776.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(419,419,'Retail',7110.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(420,420,'Retail',8674.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(421,421,'Retail',4316.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(422,422,'Retail',3226.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(423,423,'Retail',3504.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(424,424,'Retail',5976.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(425,425,'Retail',9825.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(426,426,'Retail',8862.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(427,427,'Retail',1059.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(428,428,'Retail',3529.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(429,429,'Retail',7726.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(430,430,'Retail',5625.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(431,431,'Retail',6097.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(432,432,'Retail',802.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(433,433,'Retail',1885.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(434,434,'Retail',6551.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(435,435,'Retail',965.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(436,436,'Retail',7800.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(437,437,'Retail',3450.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(438,438,'Retail',8849.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(439,439,'Retail',7129.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(440,440,'Retail',2311.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(441,441,'Retail',9379.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(442,442,'Retail',4593.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(443,443,'Retail',3877.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(444,444,'Retail',2838.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(445,445,'Retail',4514.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(446,446,'Retail',1106.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(447,447,'Retail',2028.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(448,448,'Retail',9521.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(449,449,'Retail',5663.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(450,450,'Retail',9944.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(451,451,'Retail',4023.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(452,452,'Retail',9270.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(453,453,'Retail',9512.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(454,454,'Retail',9730.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(455,455,'Retail',7322.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(456,456,'Retail',2504.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(457,457,'Retail',8411.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(458,458,'Retail',1114.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(459,459,'Retail',2523.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(460,460,'Retail',4102.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(461,461,'Retail',2904.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(462,462,'Retail',765.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(463,463,'Retail',1746.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(464,464,'Retail',755.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(465,465,'Retail',4851.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(466,466,'Retail',7198.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(467,467,'Retail',7105.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(468,468,'Retail',9648.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(469,469,'Retail',6571.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(470,470,'Retail',2585.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(471,471,'Retail',5967.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(472,472,'Retail',8835.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(473,473,'Retail',3067.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(474,474,'Retail',3417.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(475,475,'Retail',6462.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(476,476,'Retail',8383.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(477,477,'Retail',7189.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(478,478,'Retail',6072.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(479,479,'Retail',5588.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(480,480,'Retail',9983.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(481,481,'Retail',2503.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(482,482,'Retail',3189.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(483,483,'Retail',4189.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(484,484,'Retail',4055.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(485,485,'Retail',9611.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(486,486,'Retail',1176.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(487,487,'Retail',1022.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(488,488,'Retail',641.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(489,489,'Retail',9740.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(490,490,'Retail',1952.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(491,491,'Retail',3193.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(492,492,'Retail',2538.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(493,493,'Retail',8555.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(494,494,'Retail',6312.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(495,495,'Retail',8432.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(496,496,'Retail',2495.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(497,497,'Retail',1183.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(498,498,'Retail',5400.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(499,499,'Retail',2870.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(500,500,'Retail',8700.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(501,501,'Retail',2415.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(502,502,'Retail',9960.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(503,503,'Retail',3893.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(504,504,'Retail',5188.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(505,505,'Retail',3503.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(506,506,'Retail',7443.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(507,507,'Retail',6940.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(508,508,'Retail',9662.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(509,509,'Retail',5347.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(510,510,'Retail',700.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(511,511,'Retail',4612.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(512,512,'Retail',4500.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(513,513,'Retail',5759.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(514,514,'Retail',2225.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(515,515,'Retail',5908.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(516,516,'Retail',9328.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(517,517,'Retail',8319.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(518,518,'Retail',1964.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(519,519,'Retail',710.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(520,520,'Retail',6427.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(521,521,'Retail',5847.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(522,522,'Retail',5941.00,'2023-12-27 12:12:51','2023-12-27 12:12:51'),(523,523,'Retail',6680.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(524,524,'Retail',3799.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(525,525,'Retail',2553.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(526,526,'Retail',6672.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(527,527,'Retail',7373.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(528,528,'Retail',6222.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(529,529,'Retail',1288.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(530,530,'Retail',6301.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(531,531,'Retail',3255.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(532,532,'Retail',5272.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(533,533,'Retail',1934.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(534,534,'Retail',8857.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(535,535,'Retail',783.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(536,536,'Retail',4120.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(537,537,'Retail',2837.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(538,538,'Retail',8371.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(539,539,'Retail',8954.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(540,540,'Retail',5971.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(541,541,'Retail',2576.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(542,542,'Retail',7516.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(543,543,'Retail',9284.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(544,544,'Retail',2430.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(545,545,'Retail',9686.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(546,546,'Retail',2407.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(547,547,'Retail',7102.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(548,548,'Retail',9323.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(549,549,'Retail',7349.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(550,550,'Retail',7916.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(551,551,'Retail',6975.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(552,552,'Retail',3927.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(553,553,'Retail',2664.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(554,554,'Retail',8724.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(555,555,'Retail',9068.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(556,556,'Retail',8676.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(557,557,'Retail',4921.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(558,558,'Retail',2591.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(559,559,'Retail',2220.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(560,560,'Retail',3311.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(561,561,'Retail',4310.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(562,562,'Retail',4573.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(563,563,'Retail',2669.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(564,564,'Retail',8464.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(565,565,'Retail',9020.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(566,566,'Retail',9109.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(567,567,'Retail',6906.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(568,568,'Retail',6193.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(569,569,'Retail',4553.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(570,570,'Retail',4724.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(571,571,'Retail',5733.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(572,572,'Retail',6444.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(573,573,'Retail',986.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(574,574,'Retail',8796.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(575,575,'Retail',3814.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(576,576,'Retail',6226.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(577,577,'Retail',1489.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(578,578,'Retail',6527.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(579,579,'Retail',5461.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(580,580,'Retail',7501.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(581,581,'Retail',1026.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(582,582,'Retail',7280.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(583,583,'Retail',7823.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(584,584,'Retail',9101.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(585,585,'Retail',3822.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(586,586,'Retail',1946.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(587,587,'Retail',896.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(588,588,'Retail',9619.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(589,589,'Retail',4385.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(590,590,'Retail',5690.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(591,591,'Retail',1833.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(592,592,'Retail',2073.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(593,593,'Retail',6320.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(594,594,'Retail',5510.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(595,595,'Retail',7807.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(596,596,'Retail',2422.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(597,597,'Retail',4667.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(598,598,'Retail',634.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(599,599,'Retail',3722.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(600,600,'Retail',2520.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(601,601,'Retail',3602.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(602,602,'Retail',9591.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(603,603,'Retail',2587.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(604,604,'Retail',6839.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(605,605,'Retail',9014.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(606,606,'Retail',773.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(607,607,'Retail',6943.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(608,608,'Retail',1964.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(609,609,'Retail',7743.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(610,610,'Retail',5818.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(611,611,'Retail',7494.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(612,612,'Retail',6626.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(613,613,'Retail',5210.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(614,614,'Retail',4687.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(615,615,'Retail',4261.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(616,616,'Retail',3779.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(617,617,'Retail',1916.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(618,618,'Retail',1692.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(619,619,'Retail',6247.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(620,620,'Retail',9281.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(621,621,'Retail',9448.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(622,622,'Retail',3286.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(623,623,'Retail',3123.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(624,624,'Retail',9767.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(625,625,'Retail',5376.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(626,626,'Retail',5072.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(627,627,'Retail',4374.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(628,628,'Retail',1968.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(629,629,'Retail',8826.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(630,630,'Retail',6913.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(631,631,'Retail',7012.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(632,632,'Retail',7887.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(633,633,'Retail',902.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(634,634,'Retail',3946.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(635,635,'Retail',7030.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(636,636,'Retail',5878.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(637,637,'Retail',3418.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(638,638,'Retail',3318.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(639,639,'Retail',9370.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(640,640,'Retail',5860.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(641,641,'Retail',4224.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(642,642,'Retail',3382.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(643,643,'Retail',6594.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(644,644,'Retail',968.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(645,645,'Retail',8438.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(646,646,'Retail',7761.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(647,647,'Retail',6468.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(648,648,'Retail',9733.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(649,649,'Retail',9841.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(650,650,'Retail',5112.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(651,651,'Retail',3550.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(652,652,'Retail',6276.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(653,653,'Retail',9088.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(654,654,'Retail',967.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(655,655,'Retail',8320.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(656,656,'Retail',1535.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(657,657,'Retail',6406.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(658,658,'Retail',7210.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(659,659,'Retail',5414.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(660,660,'Retail',7629.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(661,661,'Retail',2368.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(662,662,'Retail',6246.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(663,663,'Retail',3211.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(664,664,'Retail',9125.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(665,665,'Retail',1975.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(666,666,'Retail',7480.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(667,667,'Retail',5304.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(668,668,'Retail',2187.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(669,669,'Retail',4435.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(670,670,'Retail',5470.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(671,671,'Retail',2845.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(672,672,'Retail',9122.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(673,673,'Retail',5489.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(674,674,'Retail',9911.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(675,675,'Retail',7959.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(676,676,'Retail',504.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(677,677,'Retail',8550.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(678,678,'Retail',3258.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(679,679,'Retail',8285.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(680,680,'Retail',5886.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(681,681,'Retail',6051.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(682,682,'Retail',1445.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(683,683,'Retail',1916.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(684,684,'Retail',5930.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(685,685,'Retail',3625.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(686,686,'Retail',9643.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(687,687,'Retail',7191.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(688,688,'Retail',5247.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(689,689,'Retail',5931.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(690,690,'Retail',1086.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(691,691,'Retail',9971.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(692,692,'Retail',1015.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(693,693,'Retail',6576.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(694,694,'Retail',8783.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(695,695,'Retail',1449.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(696,696,'Retail',2723.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(697,697,'Retail',3522.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(698,698,'Retail',4572.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(699,699,'Retail',4926.00,'2023-12-27 12:12:52','2023-12-27 12:12:52'),(700,700,'Retail',2103.00,'2023-12-27 12:12:52','2023-12-27 12:12:52');
/*!40000 ALTER TABLE `product_prices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `productID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `defaultBatch` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brandID` bigint unsigned NOT NULL,
  `categoryID` bigint unsigned NOT NULL,
  `isExpire` tinyint NOT NULL,
  `productUnit` int NOT NULL,
  `ltr` double(8,2) NOT NULL,
  `weight` double(8,2) NOT NULL,
  `grade` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alertQuantity` int DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`productID`),
  KEY `products_brandid_foreign` (`brandID`),
  KEY `products_categoryid_foreign` (`categoryID`),
  CONSTRAINT `products_brandid_foreign` FOREIGN KEY (`brandID`) REFERENCES `brands` (`brandID`),
  CONSTRAINT `products_categoryid_foreign` FOREIGN KEY (`categoryID`) REFERENCES `categories` (`categoryID`)
) ENGINE=InnoDB AUTO_INCREMENT=701 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'And she kept tossing the.','3140','def-2673',2,2,1,2,7.00,2.00,'10999',71,'https://via.placeholder.com/200x200.png/005511?text=voluptate',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(2,'Cheshire Cat,\' said Alice.','7277','def-6309',1,1,1,2,5.00,9.00,'95715',93,'https://via.placeholder.com/200x200.png/004455?text=ab',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(3,'King, the Queen, and Alice.','4685','def-7468',1,1,1,2,5.00,2.00,'60538',68,'https://via.placeholder.com/200x200.png/005500?text=eos',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(4,'The Fish-Footman began by.','1459','def-6671',2,2,1,2,6.00,4.00,'88370',76,'https://via.placeholder.com/200x200.png/00bb66?text=molestiae',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(5,'White Rabbit put on your.','1195','def-2225',1,2,1,2,7.00,3.00,'71647',82,'https://via.placeholder.com/200x200.png/00ccdd?text=aut',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(6,'MARMALADE\', but to open her.','9270','def-1729',1,1,1,3,6.00,8.00,'527',56,'https://via.placeholder.com/200x200.png/00dd44?text=est',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(7,'I\'m not Ada,\' she said, \'and.','3135','def-3858',1,2,1,1,8.00,6.00,'3409',45,'https://via.placeholder.com/200x200.png/001144?text=quia',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(8,'King put on her spectacles.','4617','def-4781',1,1,1,2,7.00,1.00,'32439',100,'https://via.placeholder.com/200x200.png/004477?text=maiores',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(9,'She did not notice this last.','3744','def-9671',2,1,1,2,2.00,2.00,'66515',35,'https://via.placeholder.com/200x200.png/0055ee?text=illum',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(10,'Dinah here, I know is, it.','3802','def-3729',1,1,1,2,2.00,1.00,'55522',58,'https://via.placeholder.com/200x200.png/00bb55?text=vel',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(11,'Queen\'s hedgehog just now.','6106','def-5021',2,1,1,1,4.00,10.00,'96893',39,'https://via.placeholder.com/200x200.png/0044dd?text=quam',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(12,'I\'ve finished.\' So they got.','9440','def-5573',2,2,1,1,8.00,8.00,'41740',78,'https://via.placeholder.com/200x200.png/00aacc?text=culpa',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(13,'Dormouse again, so she began.','5915','def-7264',2,1,1,3,4.00,7.00,'36852',66,'https://via.placeholder.com/200x200.png/00bb22?text=natus',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(14,'Alice; \'all I know I have.','5068','def-6953',2,1,1,2,9.00,5.00,'67290',56,'https://via.placeholder.com/200x200.png/005511?text=expedita',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(15,'Christmas.\' And she kept.','2986','def-9310',1,2,1,2,8.00,8.00,'40136',25,'https://via.placeholder.com/200x200.png/0066aa?text=sit',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(16,'No, I\'ve made up my mind.','6279','def-1214',2,1,1,3,5.00,10.00,'43158',53,'https://via.placeholder.com/200x200.png/00cc33?text=facilis',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(17,'Alice. \'Of course it was,\'.','2868','def-8907',1,2,1,2,6.00,2.00,'73167',22,'https://via.placeholder.com/200x200.png/0077ee?text=tempora',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(18,'Alice timidly. \'Would you.','6945','def-4217',1,2,1,2,9.00,7.00,'33555',61,'https://via.placeholder.com/200x200.png/0022ee?text=autem',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(19,'Majesty,\' said the Hatter.','2501','def-3370',1,1,1,2,4.00,5.00,'7829',76,'https://via.placeholder.com/200x200.png/006677?text=ut',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(20,'Alice had learnt several.','9189','def-6501',2,2,1,1,9.00,9.00,'52454',84,'https://via.placeholder.com/200x200.png/008855?text=voluptatibus',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(21,'King. \'Shan\'t,\' said the.','3881','def-7514',1,2,1,3,6.00,2.00,'73782',73,'https://via.placeholder.com/200x200.png/00ccdd?text=iusto',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(22,'Alice to herself, \'to be.','8062','def-1694',1,2,1,1,3.00,4.00,'35960',24,'https://via.placeholder.com/200x200.png/001188?text=unde',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(23,'Footman, \'and that for the.','9313','def-4379',2,1,1,1,8.00,4.00,'88780',30,'https://via.placeholder.com/200x200.png/00dd77?text=et',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(24,'Alice, (she had grown in the.','6797','def-5801',1,1,1,3,9.00,8.00,'55534',92,'https://via.placeholder.com/200x200.png/007733?text=aut',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(25,'Cat; and this Alice thought.','8750','def-2088',2,2,1,1,2.00,9.00,'74841',98,'https://via.placeholder.com/200x200.png/0055bb?text=esse',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(26,'Hatter: \'but you could keep.','2953','def-4039',2,2,1,3,5.00,1.00,'80072',78,'https://via.placeholder.com/200x200.png/005566?text=quia',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(27,'Dodo, pointing to the door.','6842','def-5135',2,1,1,3,4.00,6.00,'97328',54,'https://via.placeholder.com/200x200.png/00ff88?text=ut',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(28,'I mean what I get\" is the.','1487','def-4266',2,2,1,2,8.00,4.00,'8292',61,'https://via.placeholder.com/200x200.png/00bb55?text=voluptates',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(29,'It means much the same thing.','1144','def-5329',2,2,1,1,1.00,10.00,'20924',22,'https://via.placeholder.com/200x200.png/00ccbb?text=voluptatem',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(30,'Hatter: \'as the things I.','8912','def-8450',2,1,1,3,10.00,9.00,'11900',29,'https://via.placeholder.com/200x200.png/0066dd?text=cumque',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(31,'At last the Gryphon replied.','9507','def-8246',2,2,1,3,9.00,4.00,'59166',86,'https://via.placeholder.com/200x200.png/0011cc?text=quaerat',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(32,'There could be no use their.','1791','def-1746',2,1,1,2,6.00,1.00,'39013',90,'https://via.placeholder.com/200x200.png/008811?text=consectetur',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(33,'First, because I\'m on the.','5015','def-5372',1,2,1,2,5.00,5.00,'41282',61,'https://via.placeholder.com/200x200.png/006677?text=eligendi',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(34,'Why, I haven\'t had a large.','3263','def-5611',1,2,1,2,6.00,6.00,'73852',54,'https://via.placeholder.com/200x200.png/0022cc?text=molestiae',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(35,'I might venture to say but.','9297','def-6351',2,1,1,2,3.00,7.00,'42664',60,'https://via.placeholder.com/200x200.png/0033ee?text=aliquam',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(36,'Mock Turtle, \'they--you\'ve.','8286','def-9000',1,2,1,3,9.00,2.00,'19051',57,'https://via.placeholder.com/200x200.png/00eebb?text=eaque',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(37,'What made you so awfully.','5839','def-1764',2,1,1,2,7.00,9.00,'53881',37,'https://via.placeholder.com/200x200.png/0077dd?text=commodi',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(38,'Alice ventured to taste it.','1194','def-2242',1,1,1,2,2.00,9.00,'37658',28,'https://via.placeholder.com/200x200.png/001155?text=laboriosam',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(39,'So she set off at once and.','4300','def-5024',2,2,1,1,9.00,9.00,'32289',95,'https://via.placeholder.com/200x200.png/00ffee?text=aut',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(40,'If I or she should push the.','6566','def-8486',2,2,1,1,9.00,9.00,'25339',81,'https://via.placeholder.com/200x200.png/00ccff?text=ea',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(41,'Quadrille is!\' \'No, indeed,\'.','7406','def-3815',2,1,1,2,1.00,6.00,'90887',78,'https://via.placeholder.com/200x200.png/0066bb?text=nulla',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(42,'Duchess?\' \'Hush! Hush!\' said.','1882','def-5651',2,1,1,2,8.00,10.00,'21449',24,'https://via.placeholder.com/200x200.png/0055bb?text=molestias',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(43,'Beautiful, beautiful Soup!\'.','7592','def-8129',1,2,1,2,10.00,5.00,'10214',98,'https://via.placeholder.com/200x200.png/006600?text=ullam',1,'System@email.com','2023-12-27 12:12:46','2023-12-27 12:12:46'),(44,'I don\'t think,\' Alice went.','9532','def-8159',1,1,1,1,9.00,5.00,'21423',20,'https://via.placeholder.com/200x200.png/000000?text=sapiente',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(45,'Alice, feeling very curious.','3370','def-6792',2,2,1,3,6.00,2.00,'29681',57,'https://via.placeholder.com/200x200.png/000077?text=itaque',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(46,'Alice began telling them her.','7598','def-3942',1,2,1,2,9.00,7.00,'93212',72,'https://via.placeholder.com/200x200.png/007777?text=consectetur',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(47,'Queen, and Alice, were in.','7499','def-6347',2,2,1,3,7.00,3.00,'98102',93,'https://via.placeholder.com/200x200.png/003322?text=ipsam',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(48,'Then she went out, but it.','3492','def-9606',2,1,1,2,10.00,9.00,'57039',31,'https://via.placeholder.com/200x200.png/00ff11?text=facere',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(49,'As they walked off together.','3962','def-8765',1,1,1,1,5.00,10.00,'76193',52,'https://via.placeholder.com/200x200.png/0088aa?text=officia',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(50,'And how odd the directions.','2731','def-9587',2,2,1,2,9.00,8.00,'41881',49,'https://via.placeholder.com/200x200.png/004477?text=eveniet',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(51,'You MUST have meant some.','3641','def-5205',1,2,1,2,5.00,9.00,'72983',60,'https://via.placeholder.com/200x200.png/008833?text=et',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(52,'These were the two creatures.','1170','def-8507',2,1,1,2,5.00,1.00,'92503',63,'https://via.placeholder.com/200x200.png/005533?text=pariatur',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(53,'Alice a little wider. \'Come.','3978','def-4236',2,1,1,3,10.00,7.00,'24608',72,'https://via.placeholder.com/200x200.png/001155?text=corporis',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(54,'ARE OLD, FATHER WILLIAM,\' to.','6931','def-6996',2,1,1,2,10.00,10.00,'11254',98,'https://via.placeholder.com/200x200.png/009922?text=qui',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(55,'Alice could see her after.','2483','def-3866',2,2,1,1,3.00,5.00,'11066',37,'https://via.placeholder.com/200x200.png/005555?text=quibusdam',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(56,'What happened to me! When I.','8097','def-9803',2,2,1,2,8.00,6.00,'87132',94,'https://via.placeholder.com/200x200.png/0066cc?text=et',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(57,'Mouse, who was reading the.','8225','def-3410',2,1,1,3,4.00,7.00,'50817',30,'https://via.placeholder.com/200x200.png/00bbcc?text=sapiente',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(58,'Alice in a court of justice.','2279','def-8521',1,2,1,1,6.00,10.00,'69558',100,'https://via.placeholder.com/200x200.png/002288?text=quam',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(59,'I have to whisper a hint to.','5743','def-7611',1,1,1,2,1.00,4.00,'34031',95,'https://via.placeholder.com/200x200.png/000088?text=sint',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(60,'Either the well was very.','9269','def-3387',1,1,1,3,10.00,2.00,'98852',54,'https://via.placeholder.com/200x200.png/0099aa?text=fuga',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(61,'Rabbit hastily interrupted.','3476','def-2533',1,1,1,2,9.00,6.00,'39316',64,'https://via.placeholder.com/200x200.png/00eeff?text=dolore',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(62,'Mouse, who was talking. \'How.','1809','def-4167',1,2,1,1,4.00,5.00,'24974',60,'https://via.placeholder.com/200x200.png/00aa66?text=et',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(63,'Gryphon. \'They can\'t have.','5465','def-3420',1,1,1,3,2.00,6.00,'12913',29,'https://via.placeholder.com/200x200.png/00bbee?text=laborum',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(64,'At this the White Rabbit.','7569','def-4234',1,1,1,1,1.00,4.00,'12433',41,'https://via.placeholder.com/200x200.png/00ddee?text=eos',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(65,'Alice, rather doubtfully, as.','9201','def-9442',1,2,1,3,7.00,9.00,'77337',50,'https://via.placeholder.com/200x200.png/00ee77?text=culpa',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(66,'Queen merely remarking as it.','8719','def-3145',2,2,1,3,1.00,3.00,'33847',20,'https://via.placeholder.com/200x200.png/001111?text=vero',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(67,'English, who wanted leaders.','4369','def-9469',1,1,1,3,2.00,8.00,'76346',99,'https://via.placeholder.com/200x200.png/0099bb?text=unde',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(68,'I should think!\' (Dinah was.','7687','def-4995',1,1,1,1,7.00,5.00,'21774',41,'https://via.placeholder.com/200x200.png/006644?text=labore',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(69,'It was, no doubt: only Alice.','9668','def-1244',2,2,1,3,3.00,9.00,'12755',84,'https://via.placeholder.com/200x200.png/001188?text=non',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(70,'I needn\'t be afraid of it.','2170','def-7371',1,2,1,3,3.00,7.00,'59040',38,'https://via.placeholder.com/200x200.png/00ddee?text=assumenda',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(71,'HER about it.\' (The jury all.','1256','def-8354',1,2,1,1,1.00,3.00,'63911',90,'https://via.placeholder.com/200x200.png/005599?text=corrupti',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(72,'For anything tougher than.','4335','def-2197',1,1,1,1,2.00,1.00,'93428',40,'https://via.placeholder.com/200x200.png/00dd99?text=quod',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(73,'Alice. \'Off with her head!\'.','8469','def-3363',2,1,1,2,8.00,5.00,'5617',46,'https://via.placeholder.com/200x200.png/00eeee?text=asperiores',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(74,'White Rabbit put on your.','7520','def-4004',1,2,1,2,10.00,5.00,'31176',32,'https://via.placeholder.com/200x200.png/00bb00?text=aperiam',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(75,'Alice did not sneeze, were.','3157','def-5217',2,1,1,1,6.00,10.00,'38751',74,'https://via.placeholder.com/200x200.png/00eeaa?text=sit',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(76,'Hatter, \'when the Queen said.','4424','def-3675',1,1,1,3,1.00,4.00,'17859',47,'https://via.placeholder.com/200x200.png/00aaee?text=hic',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(77,'King, \'that saves a world of.','6198','def-9922',2,1,1,1,8.00,3.00,'48788',32,'https://via.placeholder.com/200x200.png/003300?text=sed',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(78,'Then came a little faster?\".','9141','def-9604',1,2,1,2,6.00,9.00,'76937',100,'https://via.placeholder.com/200x200.png/007733?text=doloremque',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(79,'Hatter went on, \'that they\'d.','7481','def-7125',2,1,1,2,5.00,6.00,'9084',60,'https://via.placeholder.com/200x200.png/008833?text=consequatur',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(80,'I to do?\' said Alice. \'Well.','6240','def-5447',2,1,1,3,5.00,3.00,'44815',62,'https://via.placeholder.com/200x200.png/009911?text=est',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(81,'Dormouse; \'--well in.\' This.','1822','def-4514',2,1,1,1,7.00,1.00,'52733',82,'https://via.placeholder.com/200x200.png/00eedd?text=ullam',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(82,'Eaglet. \'I don\'t see any.','4148','def-5952',1,1,1,3,8.00,8.00,'84960',33,'https://via.placeholder.com/200x200.png/004499?text=quasi',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(83,'Duchess asked, with another.','8069','def-8703',1,1,1,1,8.00,1.00,'84936',77,'https://via.placeholder.com/200x200.png/0022aa?text=nihil',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(84,'Alice tried to look through.','2603','def-8886',2,2,1,3,7.00,6.00,'76097',61,'https://via.placeholder.com/200x200.png/003333?text=distinctio',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(85,'I\'m quite tired of being.','3596','def-1849',1,1,1,1,1.00,4.00,'65440',49,'https://via.placeholder.com/200x200.png/00ccaa?text=error',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(86,'He looked at the bottom of.','9363','def-7030',1,1,1,1,8.00,1.00,'69321',43,'https://via.placeholder.com/200x200.png/009955?text=perferendis',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(87,'I\'m a deal faster than it.','6184','def-4756',2,1,1,2,1.00,7.00,'47503',79,'https://via.placeholder.com/200x200.png/008855?text=perspiciatis',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(88,'Though they were gardeners.','1790','def-3899',1,1,1,2,2.00,4.00,'37247',50,'https://via.placeholder.com/200x200.png/005599?text=quod',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(89,'Alice, jumping up in great.','3869','def-1342',2,1,1,3,1.00,3.00,'97239',79,'https://via.placeholder.com/200x200.png/00ddcc?text=praesentium',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(90,'Caterpillar\'s making such a.','3963','def-1214',1,1,1,2,6.00,10.00,'63457',21,'https://via.placeholder.com/200x200.png/0066ff?text=ut',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(91,'Alice: \'I don\'t know where.','9473','def-2799',1,2,1,1,6.00,4.00,'22644',24,'https://via.placeholder.com/200x200.png/00aabb?text=nesciunt',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(92,'I tell you, you coward!\' and.','5161','def-3129',2,2,1,1,4.00,9.00,'3548',76,'https://via.placeholder.com/200x200.png/0077bb?text=et',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(93,'Alice, and looking at them.','1099','def-8375',1,2,1,2,5.00,6.00,'95646',81,'https://via.placeholder.com/200x200.png/0088cc?text=doloribus',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(94,'However, this bottle does. I.','9381','def-7632',2,2,1,1,10.00,7.00,'95571',69,'https://via.placeholder.com/200x200.png/006644?text=qui',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(95,'Alice. \'I wonder if I like.','4166','def-2252',1,2,1,3,7.00,9.00,'29910',22,'https://via.placeholder.com/200x200.png/004477?text=sunt',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(96,'However, when they saw her.','6590','def-2596',1,2,1,1,3.00,5.00,'24929',46,'https://via.placeholder.com/200x200.png/0011ff?text=dolores',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(97,'Alice hastily, afraid that.','4204','def-9968',1,2,1,2,7.00,5.00,'97773',42,'https://via.placeholder.com/200x200.png/00ddff?text=nulla',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(98,'EVEN finish, if he would not.','7579','def-9766',2,1,1,3,6.00,6.00,'43659',70,'https://via.placeholder.com/200x200.png/006699?text=et',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(99,'AND WASHING--extra.\"\' \'You.','3858','def-3328',2,1,1,3,3.00,8.00,'86131',79,'https://via.placeholder.com/200x200.png/00bbbb?text=iste',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(100,'The Dormouse slowly opened.','2366','def-5326',1,2,1,1,8.00,1.00,'43252',28,'https://via.placeholder.com/200x200.png/00eedd?text=molestiae',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(101,'I\'ve fallen by this time.).','9700','def-5145',2,1,1,2,4.00,7.00,'91591',28,'https://via.placeholder.com/200x200.png/0044cc?text=non',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(102,'For some minutes it seemed.','3074','def-8357',2,1,1,2,3.00,10.00,'59894',88,'https://via.placeholder.com/200x200.png/006666?text=at',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(103,'Alice could see it trying in.','3281','def-4741',1,2,1,2,5.00,6.00,'50813',86,'https://via.placeholder.com/200x200.png/0000aa?text=ipsa',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(104,'So she was coming back to.','9746','def-5487',1,1,1,1,5.00,3.00,'59324',73,'https://via.placeholder.com/200x200.png/00ccdd?text=similique',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(105,'White Rabbit was still in.','8429','def-1915',1,2,1,3,3.00,5.00,'41695',86,'https://via.placeholder.com/200x200.png/007788?text=culpa',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(106,'Last came a little startled.','9949','def-5413',1,1,1,1,2.00,6.00,'34231',28,'https://via.placeholder.com/200x200.png/0077aa?text=culpa',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(107,'I shall never get to the.','8105','def-8464',2,1,1,3,3.00,5.00,'4563',99,'https://via.placeholder.com/200x200.png/0099ff?text=blanditiis',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(108,'I might venture to ask help.','9909','def-3651',2,2,1,3,4.00,4.00,'751',89,'https://via.placeholder.com/200x200.png/008855?text=doloremque',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(109,'She pitied him deeply. \'What.','1813','def-4422',2,2,1,2,6.00,8.00,'42435',63,'https://via.placeholder.com/200x200.png/0066ff?text=sunt',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(110,'Forty-two. ALL PERSONS MORE.','1309','def-8030',1,2,1,1,6.00,10.00,'98616',82,'https://via.placeholder.com/200x200.png/0066bb?text=culpa',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(111,'She took down a large one.','9713','def-9141',1,1,1,2,3.00,9.00,'34286',83,'https://via.placeholder.com/200x200.png/00aa77?text=rem',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(112,'Mouse. \'--I proceed. \"Edwin.','2255','def-4003',2,1,1,2,3.00,7.00,'28550',27,'https://via.placeholder.com/200x200.png/001155?text=aliquid',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(113,'Caterpillar. \'Well, I can\'t.','9737','def-7374',2,2,1,1,4.00,7.00,'61270',78,'https://via.placeholder.com/200x200.png/008855?text=repellat',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(114,'No, it\'ll never do to hold.','1523','def-1260',2,2,1,3,7.00,7.00,'31753',100,'https://via.placeholder.com/200x200.png/0055dd?text=praesentium',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(115,'I must, I must,\' the King.','8121','def-7258',1,1,1,1,8.00,10.00,'41458',90,'https://via.placeholder.com/200x200.png/0055ff?text=sed',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(116,'Alice! when she turned to.','7416','def-7342',2,1,1,3,2.00,6.00,'71529',36,'https://via.placeholder.com/200x200.png/000033?text=rerum',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(117,'The first question of course.','9306','def-6623',1,1,1,3,1.00,9.00,'34052',34,'https://via.placeholder.com/200x200.png/00dd00?text=voluptatem',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(118,'Duchess took her choice, and.','7955','def-4338',2,2,1,1,6.00,9.00,'68267',32,'https://via.placeholder.com/200x200.png/0077aa?text=earum',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(119,'Alice alone with the distant.','4829','def-3253',2,2,1,1,9.00,8.00,'68924',72,'https://via.placeholder.com/200x200.png/0077cc?text=reiciendis',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(120,'SOMETHING interesting is.','9431','def-5734',1,2,1,1,2.00,8.00,'73607',52,'https://via.placeholder.com/200x200.png/003355?text=pariatur',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(121,'Rabbit actually TOOK A WATCH.','7651','def-2952',1,2,1,3,1.00,10.00,'64869',24,'https://via.placeholder.com/200x200.png/0066ff?text=at',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(122,'There was not otherwise than.','3812','def-3068',2,2,1,1,3.00,10.00,'75912',42,'https://via.placeholder.com/200x200.png/004488?text=doloremque',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(123,'Mock Turtle Soup is made.','8460','def-2361',2,1,1,2,3.00,2.00,'559',34,'https://via.placeholder.com/200x200.png/00ddbb?text=et',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(124,'Elsie, Lacie, and Tillie.','2758','def-2987',2,2,1,3,5.00,8.00,'15250',55,'https://via.placeholder.com/200x200.png/006688?text=aut',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(125,'VERY turn-up nose, much more.','6682','def-4223',2,1,1,3,4.00,1.00,'86182',53,'https://via.placeholder.com/200x200.png/008800?text=iure',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(126,'I\'m I, and--oh dear, how.','4468','def-1126',2,2,1,3,5.00,10.00,'74021',32,'https://via.placeholder.com/200x200.png/003388?text=omnis',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(127,'Prizes!\' Alice had got its.','6520','def-9472',2,1,1,2,4.00,1.00,'66529',79,'https://via.placeholder.com/200x200.png/00bb66?text=reiciendis',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(128,'I should think it was,\' he.','5629','def-7532',1,2,1,3,5.00,5.00,'83234',95,'https://via.placeholder.com/200x200.png/0033ff?text=architecto',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(129,'I THINK; or is it twelve?.','7243','def-9278',2,1,1,1,7.00,3.00,'74077',36,'https://via.placeholder.com/200x200.png/00ff88?text=vitae',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(130,'Hatter. He came in sight of.','3962','def-5448',1,2,1,1,5.00,9.00,'43911',74,'https://via.placeholder.com/200x200.png/009999?text=natus',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(131,'Where CAN I have none, Why.','1514','def-2829',2,2,1,1,4.00,4.00,'9915',30,'https://via.placeholder.com/200x200.png/00cc55?text=iusto',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(132,'Oh, how I wish you wouldn\'t.','9520','def-4541',2,2,1,2,10.00,4.00,'18711',79,'https://via.placeholder.com/200x200.png/00eecc?text=aut',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(133,'Duchess, the Duchess! Oh!.','7809','def-9995',1,1,1,3,5.00,8.00,'53822',63,'https://via.placeholder.com/200x200.png/0077bb?text=eum',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(134,'And she squeezed herself up.','6409','def-8791',2,2,1,2,1.00,1.00,'4944',21,'https://via.placeholder.com/200x200.png/0055ee?text=provident',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(135,'Alice. \'I mean what I should.','8583','def-9179',2,2,1,3,2.00,4.00,'78691',95,'https://via.placeholder.com/200x200.png/004477?text=delectus',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(136,'But, now that I\'m doubtful.','8710','def-1978',2,1,1,2,7.00,5.00,'75309',62,'https://via.placeholder.com/200x200.png/0044bb?text=ipsa',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(137,'KNOW IT TO BE TRUE--\" that\'s.','8078','def-1986',1,2,1,1,7.00,8.00,'17366',50,'https://via.placeholder.com/200x200.png/00ee77?text=alias',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(138,'There was nothing so VERY.','4493','def-7652',2,2,1,2,1.00,8.00,'2975',81,'https://via.placeholder.com/200x200.png/00aabb?text=quas',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(139,'The Dormouse had closed its.','3328','def-2850',2,2,1,2,4.00,4.00,'16421',38,'https://via.placeholder.com/200x200.png/00aa00?text=illum',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(140,'Queen put on one knee as he.','2286','def-8217',1,2,1,1,4.00,2.00,'57428',25,'https://via.placeholder.com/200x200.png/00dd66?text=quia',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(141,'She soon got it out into the.','6375','def-8727',1,2,1,2,6.00,10.00,'35478',78,'https://via.placeholder.com/200x200.png/005577?text=praesentium',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(142,'Alice)--\'and perhaps you.','3204','def-1111',1,1,1,1,3.00,7.00,'31796',27,'https://via.placeholder.com/200x200.png/001100?text=et',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(143,'Alice, as she listened, or.','8903','def-4132',2,2,1,1,9.00,4.00,'5569',32,'https://via.placeholder.com/200x200.png/00cc88?text=sint',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(144,'Rabbit hastily interrupted.','1325','def-1741',2,1,1,2,7.00,4.00,'14614',42,'https://via.placeholder.com/200x200.png/0022dd?text=qui',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(145,'I hadn\'t quite finished my.','5464','def-6702',1,1,1,1,8.00,4.00,'88150',53,'https://via.placeholder.com/200x200.png/00bb77?text=perspiciatis',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(146,'WHAT?\' thought Alice; \'only.','7566','def-8669',2,2,1,1,9.00,10.00,'15680',58,'https://via.placeholder.com/200x200.png/0066bb?text=ea',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(147,'King, \'that saves a world of.','1553','def-4046',2,2,1,3,6.00,1.00,'39943',46,'https://via.placeholder.com/200x200.png/00ff77?text=quidem',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(148,'Alice remarked. \'Right, as.','7132','def-1107',2,2,1,1,2.00,9.00,'54804',94,'https://via.placeholder.com/200x200.png/00ddee?text=ad',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(149,'The great question certainly.','7318','def-2689',2,1,1,3,9.00,7.00,'21236',43,'https://via.placeholder.com/200x200.png/000044?text=dolores',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(150,'When they take us up and.','6855','def-8146',2,1,1,1,9.00,6.00,'62985',98,'https://via.placeholder.com/200x200.png/00cc99?text=et',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(151,'Alice; \'I might as well she.','2123','def-7433',1,1,1,1,1.00,6.00,'24511',68,'https://via.placeholder.com/200x200.png/00ee88?text=quas',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(152,'I must, I must,\' the King.','5441','def-2741',1,2,1,3,6.00,5.00,'97772',47,'https://via.placeholder.com/200x200.png/00bb99?text=qui',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(153,'It quite makes my forehead.','8175','def-6693',2,1,1,1,7.00,9.00,'97979',53,'https://via.placeholder.com/200x200.png/006633?text=est',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(154,'Alice for some time busily.','9922','def-8699',1,2,1,1,4.00,8.00,'65625',33,'https://via.placeholder.com/200x200.png/00aaaa?text=dolorem',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(155,'I\'ve got to do,\' said Alice.','8017','def-1057',1,2,1,1,8.00,5.00,'17356',98,'https://via.placeholder.com/200x200.png/0033cc?text=aperiam',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(156,'NOT marked \'poison,\' it is.','6085','def-3209',1,1,1,2,10.00,8.00,'79582',74,'https://via.placeholder.com/200x200.png/0022bb?text=dolorum',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(157,'Lobster Quadrille, that she.','9001','def-6017',1,2,1,1,6.00,5.00,'42699',36,'https://via.placeholder.com/200x200.png/000033?text=perspiciatis',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(158,'Wonderland, though she knew.','4784','def-1950',2,2,1,2,9.00,6.00,'6082',26,'https://via.placeholder.com/200x200.png/008866?text=qui',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(159,'I\'ll come up: if not, I\'ll.','6225','def-3888',1,1,1,2,1.00,1.00,'20627',51,'https://via.placeholder.com/200x200.png/0099dd?text=cupiditate',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(160,'Alice, who always took a.','7136','def-6656',1,1,1,1,8.00,3.00,'14827',60,'https://via.placeholder.com/200x200.png/00ddbb?text=tenetur',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(161,'March Hare said in a natural.','5256','def-5419',1,1,1,1,5.00,8.00,'61940',37,'https://via.placeholder.com/200x200.png/00cc99?text=magnam',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(162,'White Rabbit hurried by--the.','9739','def-6121',2,1,1,3,5.00,6.00,'35085',88,'https://via.placeholder.com/200x200.png/004499?text=adipisci',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(163,'William\'s conduct at first.','8401','def-6390',2,2,1,1,2.00,2.00,'96107',51,'https://via.placeholder.com/200x200.png/002266?text=ducimus',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(164,'Which shall sing?\' \'Oh, YOU.','9995','def-4177',1,2,1,1,1.00,9.00,'10958',90,'https://via.placeholder.com/200x200.png/0077ff?text=et',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(165,'These were the cook, to see.','3195','def-3143',2,2,1,1,6.00,2.00,'42037',22,'https://via.placeholder.com/200x200.png/00bb00?text=doloribus',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(166,'Alice had been wandering.','1572','def-9432',2,2,1,1,1.00,9.00,'9947',39,'https://via.placeholder.com/200x200.png/00bb99?text=ipsam',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(167,'The executioner\'s argument.','4326','def-7768',1,1,1,2,2.00,3.00,'86885',61,'https://via.placeholder.com/200x200.png/00ff66?text=quos',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(168,'There ought to be lost, as.','6334','def-5827',2,1,1,1,10.00,7.00,'28304',66,'https://via.placeholder.com/200x200.png/006666?text=dolor',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(169,'Alas! it was in the middle.','2856','def-6202',2,1,1,3,10.00,8.00,'66706',43,'https://via.placeholder.com/200x200.png/00aa22?text=earum',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(170,'Ann!\' said the White Rabbit.','2031','def-2240',2,1,1,1,8.00,5.00,'99501',31,'https://via.placeholder.com/200x200.png/00dddd?text=hic',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(171,'Alice, \'they\'re sure to do.','4322','def-7436',1,1,1,2,3.00,2.00,'56113',26,'https://via.placeholder.com/200x200.png/0022dd?text=ut',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(172,'ARE OLD, FATHER WILLIAM,\"\'.','3852','def-1557',2,2,1,1,3.00,5.00,'65363',59,'https://via.placeholder.com/200x200.png/0033bb?text=reprehenderit',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(173,'She was moving them about as.','9154','def-4925',2,2,1,1,4.00,4.00,'14056',86,'https://via.placeholder.com/200x200.png/001133?text=asperiores',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(174,'Then followed the Knave of.','8938','def-9693',2,2,1,3,9.00,8.00,'59142',95,'https://via.placeholder.com/200x200.png/00dd77?text=optio',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(175,'Alice did not appear, and.','5012','def-3253',1,2,1,3,2.00,1.00,'26389',25,'https://via.placeholder.com/200x200.png/000022?text=molestiae',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(176,'King. \'Nothing whatever,\'.','1761','def-4449',2,1,1,3,7.00,2.00,'10686',54,'https://via.placeholder.com/200x200.png/0011aa?text=aut',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(177,'And she thought to herself.','9802','def-2374',2,1,1,1,9.00,9.00,'98177',44,'https://via.placeholder.com/200x200.png/00ff44?text=non',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(178,'Footman went on \'And how did.','3267','def-2339',2,2,1,1,9.00,6.00,'45261',40,'https://via.placeholder.com/200x200.png/0044bb?text=autem',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(179,'WOULD put their heads down.','8167','def-9330',1,2,1,3,1.00,6.00,'55506',91,'https://via.placeholder.com/200x200.png/008811?text=cupiditate',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(180,'But, now that I\'m doubtful.','3645','def-8702',1,2,1,2,8.00,10.00,'98764',64,'https://via.placeholder.com/200x200.png/00eecc?text=corrupti',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(181,'The only things in the way.','8494','def-1040',1,1,1,3,8.00,8.00,'14967',82,'https://via.placeholder.com/200x200.png/00bb77?text=odio',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(182,'Shall I try the effect: the.','1751','def-9307',1,2,1,1,5.00,6.00,'83681',94,'https://via.placeholder.com/200x200.png/004400?text=velit',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(183,'Mock Turtle went on, turning.','4076','def-1823',2,2,1,1,2.00,7.00,'87432',65,'https://via.placeholder.com/200x200.png/00ddcc?text=quasi',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(184,'FOOT, ESQ. HEARTHRUG, NEAR.','6038','def-2678',1,1,1,2,9.00,4.00,'29718',22,'https://via.placeholder.com/200x200.png/0011bb?text=corporis',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(185,'Hatter with a large kitchen.','8759','def-4882',1,2,1,2,9.00,3.00,'62144',52,'https://via.placeholder.com/200x200.png/00eeaa?text=enim',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(186,'Alice dodged behind a great.','1196','def-6493',1,1,1,2,5.00,2.00,'47615',66,'https://via.placeholder.com/200x200.png/00ff44?text=expedita',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(187,'Duchess: \'flamingoes and.','2785','def-6148',2,1,1,3,4.00,4.00,'58358',43,'https://via.placeholder.com/200x200.png/00aa00?text=blanditiis',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(188,'Conqueror.\' (For, with all.','1853','def-5986',2,1,1,1,9.00,7.00,'2138',70,'https://via.placeholder.com/200x200.png/00aabb?text=quidem',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(189,'Duchess, \'and that\'s the.','5568','def-8910',1,1,1,3,7.00,6.00,'15355',35,'https://via.placeholder.com/200x200.png/004444?text=ipsum',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(190,'They had a head unless there.','5938','def-1437',2,2,1,3,3.00,3.00,'76073',99,'https://via.placeholder.com/200x200.png/0077aa?text=quia',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(191,'I am in the lap of her sharp.','5259','def-5777',1,2,1,2,5.00,5.00,'6979',82,'https://via.placeholder.com/200x200.png/000033?text=quae',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(192,'The further off from England.','9287','def-8512',1,1,1,3,8.00,8.00,'68460',80,'https://via.placeholder.com/200x200.png/0022cc?text=ut',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(193,'YOUR opinion,\' said Alice.','6027','def-9374',1,2,1,1,1.00,6.00,'61107',58,'https://via.placeholder.com/200x200.png/0088bb?text=reiciendis',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(194,'Caterpillar. \'Is that the.','8152','def-6034',2,2,1,1,10.00,3.00,'85983',37,'https://via.placeholder.com/200x200.png/00aa88?text=perspiciatis',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(195,'Alice was more hopeless than.','2498','def-2575',1,2,1,1,3.00,8.00,'36748',35,'https://via.placeholder.com/200x200.png/00bb44?text=tenetur',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(196,'RED rose-tree, and we won\'t.','3695','def-9297',1,2,1,1,3.00,1.00,'8201',84,'https://via.placeholder.com/200x200.png/00dd44?text=et',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(197,'King and Queen of Hearts.','7398','def-4823',2,2,1,1,8.00,5.00,'17588',94,'https://via.placeholder.com/200x200.png/0044bb?text=quia',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(198,'I ever saw one that size?.','1344','def-5660',2,1,1,2,5.00,10.00,'49414',46,'https://via.placeholder.com/200x200.png/0077cc?text=at',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(199,'Rabbit say, \'A barrowful.','9602','def-6456',1,2,1,2,7.00,1.00,'15640',83,'https://via.placeholder.com/200x200.png/0000cc?text=quod',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(200,'They had not long to doubt.','3179','def-7753',2,2,1,1,6.00,1.00,'79940',59,'https://via.placeholder.com/200x200.png/00aa99?text=placeat',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(201,'However, I\'ve got to come.','2626','def-3203',2,1,1,2,4.00,7.00,'85046',74,'https://via.placeholder.com/200x200.png/005566?text=velit',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(202,'Queen put on one side, to.','7571','def-7190',1,1,1,2,5.00,4.00,'29531',33,'https://via.placeholder.com/200x200.png/000055?text=molestias',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(203,'Queen, \'and take this young.','2685','def-5848',1,2,1,3,7.00,9.00,'4163',69,'https://via.placeholder.com/200x200.png/00ee00?text=est',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(204,'Father William,\' the young.','7417','def-6524',2,1,1,2,2.00,6.00,'13107',26,'https://via.placeholder.com/200x200.png/0011aa?text=minus',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(205,'I never understood what it.','4817','def-1125',1,1,1,1,6.00,2.00,'83769',47,'https://via.placeholder.com/200x200.png/00ee66?text=consequatur',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(206,'Seven looked up and walking.','7527','def-7255',2,1,1,1,4.00,9.00,'62738',38,'https://via.placeholder.com/200x200.png/0011ee?text=ad',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(207,'King, and the poor little.','3928','def-9445',1,2,1,2,4.00,6.00,'58221',50,'https://via.placeholder.com/200x200.png/00aaee?text=non',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(208,'IS it to annoy, Because he.','6086','def-1325',2,2,1,2,5.00,1.00,'1306',76,'https://via.placeholder.com/200x200.png/009955?text=voluptas',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(209,'Dormouse, who seemed too.','9940','def-8797',2,1,1,2,6.00,3.00,'98339',50,'https://via.placeholder.com/200x200.png/00ccaa?text=earum',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(210,'Alice. \'I\'ve so often read.','6313','def-2108',1,2,1,3,1.00,7.00,'65015',79,'https://via.placeholder.com/200x200.png/002211?text=quo',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(211,'The March Hare interrupted.','7127','def-4882',2,2,1,1,4.00,8.00,'31875',82,'https://via.placeholder.com/200x200.png/00bb77?text=dolor',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(212,'Alice, \'and those twelve.','7997','def-7983',2,2,1,2,5.00,2.00,'68006',70,'https://via.placeholder.com/200x200.png/004455?text=culpa',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(213,'Soup! Soup of the Gryphon.','7324','def-3819',1,1,1,3,1.00,2.00,'72140',20,'https://via.placeholder.com/200x200.png/004422?text=id',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(214,'There was no longer to be no.','8026','def-2207',2,2,1,1,1.00,6.00,'69943',27,'https://via.placeholder.com/200x200.png/00eedd?text=consequatur',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(215,'Alice replied, so eagerly.','7761','def-7135',2,1,1,3,4.00,5.00,'25406',28,'https://via.placeholder.com/200x200.png/002233?text=in',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(216,'Mock Turtle recovered his.','4049','def-3559',2,1,1,1,7.00,6.00,'23059',63,'https://via.placeholder.com/200x200.png/005533?text=veritatis',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(217,'Caterpillar. \'Well, I\'ve.','5052','def-6572',2,2,1,1,9.00,7.00,'48170',83,'https://via.placeholder.com/200x200.png/0011dd?text=ratione',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(218,'I hadn\'t mentioned Dinah!\'.','9693','def-8858',2,1,1,1,8.00,4.00,'82583',51,'https://via.placeholder.com/200x200.png/0066bb?text=odit',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(219,'Alice, as she swam nearer to.','3143','def-7076',1,1,1,3,9.00,8.00,'13465',62,'https://via.placeholder.com/200x200.png/0088aa?text=tenetur',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(220,'Alice waited patiently until.','3403','def-5577',2,1,1,3,9.00,6.00,'76330',71,'https://via.placeholder.com/200x200.png/009944?text=veniam',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(221,'Pigeon. \'I can tell you my.','6786','def-5559',2,2,1,2,5.00,6.00,'88811',78,'https://via.placeholder.com/200x200.png/007733?text=dignissimos',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(222,'IT,\' the Mouse was bristling.','1834','def-2846',2,1,1,3,8.00,9.00,'78980',57,'https://via.placeholder.com/200x200.png/00cc44?text=dicta',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(223,'I must go and live in that.','2091','def-4131',2,1,1,3,1.00,10.00,'2399',61,'https://via.placeholder.com/200x200.png/009944?text=nihil',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(224,'King: \'leave out that she.','6565','def-8344',2,2,1,1,7.00,8.00,'59935',29,'https://via.placeholder.com/200x200.png/00ffcc?text=occaecati',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(225,'I shall be late!\' (when she.','2893','def-9361',2,1,1,1,8.00,8.00,'58568',51,'https://via.placeholder.com/200x200.png/0088ff?text=rerum',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(226,'Soup? Pennyworth only of.','1030','def-4751',1,1,1,2,1.00,10.00,'73978',95,'https://via.placeholder.com/200x200.png/004422?text=consequatur',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(227,'I can remember feeling a.','1720','def-1389',1,1,1,2,5.00,9.00,'48732',29,'https://via.placeholder.com/200x200.png/005599?text=sed',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(228,'I suppose.\' So she swallowed.','3295','def-1307',1,1,1,1,10.00,2.00,'19086',26,'https://via.placeholder.com/200x200.png/00bb55?text=id',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(229,'I hate cats and dogs.\' It.','5767','def-3271',1,2,1,1,6.00,10.00,'35917',94,'https://via.placeholder.com/200x200.png/00cccc?text=autem',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(230,'I\'ll get into her eyes--and.','5737','def-8768',2,2,1,3,5.00,10.00,'20154',50,'https://via.placeholder.com/200x200.png/003344?text=quidem',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(231,'Duchess: you\'d better leave.','5238','def-6984',1,2,1,3,8.00,8.00,'68323',77,'https://via.placeholder.com/200x200.png/0099ff?text=enim',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(232,'And oh, my poor hands, how.','1516','def-4105',2,1,1,3,5.00,8.00,'33491',55,'https://via.placeholder.com/200x200.png/00aa66?text=voluptas',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(233,'Five. \'I heard the Rabbit.','4354','def-8649',1,1,1,3,2.00,10.00,'44111',26,'https://via.placeholder.com/200x200.png/00cc22?text=asperiores',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(234,'King said gravely, \'and go.','1584','def-4818',1,2,1,3,10.00,10.00,'93491',33,'https://via.placeholder.com/200x200.png/00ee88?text=iusto',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(235,'When I used to queer things.','2760','def-8925',2,1,1,3,4.00,2.00,'39447',33,'https://via.placeholder.com/200x200.png/0022aa?text=ad',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(236,'The jury all wrote down all.','3256','def-1643',1,2,1,3,2.00,8.00,'51840',61,'https://via.placeholder.com/200x200.png/00ee99?text=repellat',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(237,'Alice could think of nothing.','8028','def-5900',1,1,1,1,2.00,8.00,'55709',39,'https://via.placeholder.com/200x200.png/00ff99?text=deleniti',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(238,'I breathe\"!\' \'It IS a long.','6865','def-8534',2,1,1,1,2.00,4.00,'53753',70,'https://via.placeholder.com/200x200.png/0066dd?text=velit',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(239,'She\'ll get me executed, as.','1937','def-8739',1,1,1,3,6.00,6.00,'57137',89,'https://via.placeholder.com/200x200.png/0011ff?text=cum',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(240,'However, she soon made out.','3210','def-2814',1,2,1,1,8.00,4.00,'48639',56,'https://via.placeholder.com/200x200.png/00ff77?text=aut',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(241,'I can say.\' This was not.','3719','def-2300',2,2,1,2,3.00,1.00,'28018',59,'https://via.placeholder.com/200x200.png/00ff88?text=unde',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(242,'There was nothing else to.','4625','def-2523',1,2,1,3,10.00,8.00,'3212',89,'https://via.placeholder.com/200x200.png/0077dd?text=soluta',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(243,'Alice looked down at her.','3436','def-2608',2,2,1,2,9.00,8.00,'15672',34,'https://via.placeholder.com/200x200.png/0066cc?text=modi',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(244,'Mock Turtle interrupted, \'if.','6177','def-4646',2,2,1,3,5.00,3.00,'18873',87,'https://via.placeholder.com/200x200.png/00bbbb?text=rerum',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(245,'Duchess said in a whisper.).','3303','def-4859',1,2,1,2,4.00,9.00,'21889',71,'https://via.placeholder.com/200x200.png/0099ff?text=sit',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(246,'Alice, surprised at this.','4582','def-3520',2,2,1,1,4.00,8.00,'87389',51,'https://via.placeholder.com/200x200.png/004433?text=dolores',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(247,'Be off, or I\'ll kick you.','8895','def-7707',2,2,1,2,3.00,5.00,'66986',32,'https://via.placeholder.com/200x200.png/0000ee?text=perspiciatis',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(248,'VERY remarkable in that; nor.','5352','def-1292',1,2,1,1,2.00,7.00,'58905',65,'https://via.placeholder.com/200x200.png/0044ee?text=fugit',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(249,'Alice thought to herself.','8621','def-6301',2,1,1,3,7.00,6.00,'30636',69,'https://via.placeholder.com/200x200.png/00dd88?text=quia',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(250,'Cat. \'I said pig,\' replied.','4508','def-3172',1,2,1,1,7.00,3.00,'78495',38,'https://via.placeholder.com/200x200.png/00aa22?text=quam',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(251,'Cat said, waving its tail.','4748','def-3317',1,1,1,3,6.00,6.00,'8108',84,'https://via.placeholder.com/200x200.png/007711?text=ratione',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(252,'I think I should be free of.','5400','def-9724',1,1,1,2,6.00,5.00,'10209',27,'https://via.placeholder.com/200x200.png/00ee77?text=officiis',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(253,'Pigeon; \'but if you\'ve seen.','4543','def-1452',1,2,1,2,3.00,9.00,'45951',43,'https://via.placeholder.com/200x200.png/0044dd?text=ut',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(254,'The first witness was the.','5785','def-2578',2,1,1,3,8.00,1.00,'35454',56,'https://via.placeholder.com/200x200.png/005555?text=fugit',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(255,'The moment Alice appeared.','4395','def-6658',1,1,1,3,5.00,1.00,'75132',59,'https://via.placeholder.com/200x200.png/00eebb?text=architecto',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(256,'And he got up and ran till.','2133','def-4149',1,1,1,1,10.00,4.00,'23416',31,'https://via.placeholder.com/200x200.png/00cc88?text=porro',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(257,'I shall be punished for it.','3534','def-4739',1,1,1,3,1.00,7.00,'7522',90,'https://via.placeholder.com/200x200.png/00aa55?text=impedit',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(258,'After a while she was now.','3860','def-2299',1,1,1,1,4.00,1.00,'73122',57,'https://via.placeholder.com/200x200.png/00cccc?text=quisquam',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(259,'It was opened by another.','6827','def-3488',1,2,1,1,8.00,10.00,'2868',46,'https://via.placeholder.com/200x200.png/00eeee?text=quos',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(260,'She felt that it was empty.','4857','def-2403',2,2,1,2,4.00,5.00,'19325',28,'https://via.placeholder.com/200x200.png/00aadd?text=numquam',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(261,'Where CAN I have done that.','3481','def-6435',1,1,1,2,9.00,7.00,'43243',87,'https://via.placeholder.com/200x200.png/007766?text=odit',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(262,'And the muscular strength.','3455','def-6634',1,1,1,2,3.00,3.00,'25405',31,'https://via.placeholder.com/200x200.png/0077dd?text=quod',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(263,'VERY turn-up nose, much more.','6613','def-5473',1,1,1,3,10.00,6.00,'52797',68,'https://via.placeholder.com/200x200.png/0033ff?text=suscipit',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(264,'Alice, a good many voices.','7896','def-2042',2,2,1,2,2.00,3.00,'48615',24,'https://via.placeholder.com/200x200.png/0000cc?text=omnis',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(265,'Rabbit, and had been found.','5484','def-6189',1,2,1,2,1.00,6.00,'1797',72,'https://via.placeholder.com/200x200.png/008822?text=et',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(266,'King said, for about the.','2728','def-6373',1,2,1,2,7.00,3.00,'1416',37,'https://via.placeholder.com/200x200.png/0088ff?text=ut',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(267,'Alice\'s side as she came in.','5740','def-9502',2,1,1,3,10.00,9.00,'58588',39,'https://via.placeholder.com/200x200.png/005522?text=qui',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(268,'I\'m not myself, you see.\' \'I.','6571','def-5283',2,2,1,3,3.00,3.00,'29200',61,'https://via.placeholder.com/200x200.png/0055ee?text=eligendi',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(269,'I should think!\' (Dinah was.','5138','def-5404',1,2,1,2,7.00,3.00,'80970',27,'https://via.placeholder.com/200x200.png/002255?text=rerum',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(270,'Caterpillar angrily, rearing.','8175','def-7742',1,1,1,2,2.00,10.00,'53556',85,'https://via.placeholder.com/200x200.png/00aa11?text=saepe',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(271,'Lobster Quadrille, that she.','9310','def-7962',1,1,1,2,8.00,4.00,'13070',83,'https://via.placeholder.com/200x200.png/00dd11?text=magni',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(272,'X. The Lobster Quadrille The.','9925','def-2562',2,1,1,1,8.00,8.00,'91664',37,'https://via.placeholder.com/200x200.png/00cc66?text=aut',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(273,'Presently the Rabbit coming.','7718','def-4026',2,1,1,1,10.00,3.00,'20005',81,'https://via.placeholder.com/200x200.png/004466?text=tempora',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(274,'Queen will hear you! You.','3852','def-2924',1,2,1,2,4.00,6.00,'10628',52,'https://via.placeholder.com/200x200.png/004411?text=a',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(275,'After these came the guests.','2811','def-8005',1,2,1,1,9.00,8.00,'93237',26,'https://via.placeholder.com/200x200.png/00aa66?text=ut',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(276,'However, I\'ve got to the.','5631','def-3280',2,1,1,3,9.00,4.00,'51131',37,'https://via.placeholder.com/200x200.png/00aa55?text=sit',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(277,'I\'m afraid, sir\' said Alice.','8657','def-9853',1,2,1,2,9.00,6.00,'55204',84,'https://via.placeholder.com/200x200.png/0033aa?text=placeat',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(278,'I see\"!\' \'You might just as.','3995','def-4793',2,1,1,2,7.00,6.00,'20111',35,'https://via.placeholder.com/200x200.png/008844?text=ipsum',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(279,'THEIR eyes bright and eager.','7246','def-5624',2,1,1,3,5.00,6.00,'75127',39,'https://via.placeholder.com/200x200.png/008899?text=molestias',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(280,'Queen. \'Never!\' said the.','9843','def-9640',1,2,1,2,3.00,2.00,'65159',58,'https://via.placeholder.com/200x200.png/000033?text=rerum',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(281,'Alice. \'Come, let\'s hear.','6520','def-6738',1,1,1,2,1.00,8.00,'99271',30,'https://via.placeholder.com/200x200.png/00ff66?text=assumenda',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(282,'And in she went. Once more.','2457','def-9148',2,2,1,1,10.00,9.00,'94127',75,'https://via.placeholder.com/200x200.png/00cc55?text=illo',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(283,'Alice, and sighing. \'It IS a.','1644','def-1472',1,2,1,2,10.00,5.00,'6963',52,'https://via.placeholder.com/200x200.png/0055bb?text=error',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(284,'Alice. \'And where HAVE my.','6993','def-2581',1,1,1,1,3.00,4.00,'39306',61,'https://via.placeholder.com/200x200.png/00ff66?text=exercitationem',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(285,'Pigeon; \'but I know is, it.','8240','def-1854',1,1,1,2,5.00,8.00,'46365',34,'https://via.placeholder.com/200x200.png/0077dd?text=deserunt',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(286,'Alice, very much pleased at.','1255','def-6642',1,1,1,2,1.00,6.00,'30882',74,'https://via.placeholder.com/200x200.png/00ff44?text=ipsam',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(287,'YOUR business, Two!\' said.','7213','def-1100',1,1,1,3,8.00,7.00,'84174',49,'https://via.placeholder.com/200x200.png/00aa44?text=illo',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(288,'Alice could not even room.','5466','def-1663',1,1,1,1,3.00,2.00,'19264',82,'https://via.placeholder.com/200x200.png/006622?text=voluptatem',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(289,'MYSELF, I\'m afraid, sir\'.','7219','def-2578',2,2,1,2,10.00,5.00,'17763',84,'https://via.placeholder.com/200x200.png/005511?text=qui',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(290,'CHAPTER V. Advice from a.','1565','def-4420',2,1,1,3,10.00,10.00,'52621',85,'https://via.placeholder.com/200x200.png/0011dd?text=illum',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(291,'I don\'t like it, yer honour.','3129','def-7890',1,1,1,1,6.00,9.00,'84308',89,'https://via.placeholder.com/200x200.png/00ddbb?text=omnis',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(292,'The chief difficulty Alice.','7259','def-1384',2,1,1,1,2.00,5.00,'57571',40,'https://via.placeholder.com/200x200.png/00ffdd?text=dolorum',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(293,'There seemed to quiver all.','5348','def-7738',1,2,1,1,10.00,8.00,'91725',80,'https://via.placeholder.com/200x200.png/003399?text=vel',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(294,'Forty-two. ALL PERSONS MORE.','5210','def-3747',1,1,1,3,2.00,3.00,'58133',48,'https://via.placeholder.com/200x200.png/00dd55?text=consectetur',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(295,'Alice waited patiently until.','5236','def-6801',1,1,1,2,8.00,5.00,'22445',98,'https://via.placeholder.com/200x200.png/00aa77?text=sed',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(296,'Gryphon. \'Well, I should.','4518','def-6029',1,2,1,3,10.00,6.00,'30882',97,'https://via.placeholder.com/200x200.png/008899?text=saepe',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(297,'Alice could hear the very.','9511','def-6248',2,1,1,2,6.00,5.00,'20029',20,'https://via.placeholder.com/200x200.png/00ee44?text=maxime',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(298,'Queen. \'It proves nothing of.','2794','def-2275',2,1,1,1,6.00,2.00,'31878',72,'https://via.placeholder.com/200x200.png/007777?text=officia',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(299,'March Hare: she thought to.','4628','def-4919',1,2,1,1,10.00,1.00,'28900',94,'https://via.placeholder.com/200x200.png/00aa33?text=minus',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(300,'Dinah my dear! Let this be a.','9916','def-7721',1,2,1,1,2.00,4.00,'65901',68,'https://via.placeholder.com/200x200.png/002222?text=at',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(301,'Caterpillar. \'Is that all?\'.','1306','def-6238',1,1,1,1,8.00,6.00,'71668',82,'https://via.placeholder.com/200x200.png/001166?text=qui',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(302,'Presently she began nibbling.','7231','def-2688',2,1,1,1,2.00,7.00,'49109',56,'https://via.placeholder.com/200x200.png/009933?text=deserunt',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(303,'Puss,\' she began, in rather.','2596','def-7786',2,1,1,3,9.00,5.00,'26938',74,'https://via.placeholder.com/200x200.png/00dd55?text=quo',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(304,'Involved in this affair, He.','8650','def-5220',2,1,1,2,9.00,6.00,'44493',91,'https://via.placeholder.com/200x200.png/001199?text=qui',1,'System@email.com','2023-12-27 12:12:47','2023-12-27 12:12:47'),(305,'ARE OLD, FATHER WILLIAM,\' to.','7658','def-1921',1,2,1,2,2.00,2.00,'78548',75,'https://via.placeholder.com/200x200.png/0099dd?text=mollitia',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(306,'King; \'and don\'t be nervous.','2847','def-8695',1,1,1,2,8.00,3.00,'81089',54,'https://via.placeholder.com/200x200.png/0077ee?text=nam',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(307,'But she did not look at all.','4123','def-3685',2,1,1,1,7.00,8.00,'30612',29,'https://via.placeholder.com/200x200.png/002266?text=sunt',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(308,'Queen. \'You make me smaller.','7989','def-3647',1,2,1,1,5.00,2.00,'56858',76,'https://via.placeholder.com/200x200.png/0044dd?text=quasi',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(309,'March Hare. \'Exactly so,\'.','2404','def-6610',1,2,1,1,4.00,2.00,'64435',36,'https://via.placeholder.com/200x200.png/009988?text=non',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(310,'They all made a memorandum.','9725','def-4795',2,1,1,2,1.00,4.00,'9727',52,'https://via.placeholder.com/200x200.png/005533?text=et',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(311,'I the same solemn tone, only.','8289','def-6828',1,2,1,2,5.00,9.00,'35817',34,'https://via.placeholder.com/200x200.png/00bbcc?text=odit',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(312,'The Hatter shook his head.','6548','def-9589',1,1,1,2,6.00,7.00,'82309',59,'https://via.placeholder.com/200x200.png/00aa11?text=vel',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(313,'King eagerly, and he checked.','2808','def-8504',1,2,1,3,2.00,4.00,'64553',66,'https://via.placeholder.com/200x200.png/001177?text=eligendi',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(314,'Alice. \'Oh, don\'t bother.','6349','def-4681',2,1,1,1,5.00,8.00,'8775',69,'https://via.placeholder.com/200x200.png/007722?text=voluptatum',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(315,'I\'ll never go THERE again!\'.','6326','def-4615',2,2,1,1,6.00,3.00,'94302',94,'https://via.placeholder.com/200x200.png/0066ee?text=ut',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(316,'Duck and a long way back.','7536','def-1538',2,2,1,1,8.00,6.00,'20024',28,'https://via.placeholder.com/200x200.png/006688?text=maxime',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(317,'Dormouse, who was sitting.','1755','def-9159',1,2,1,3,7.00,9.00,'6272',96,'https://via.placeholder.com/200x200.png/0011aa?text=velit',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(318,'Dinah: I think I can kick a.','7007','def-6326',2,2,1,1,8.00,4.00,'17188',90,'https://via.placeholder.com/200x200.png/007733?text=labore',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(319,'And concluded the banquet--].','5561','def-9988',2,2,1,1,5.00,4.00,'73881',48,'https://via.placeholder.com/200x200.png/00bb55?text=veritatis',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(320,'Alice. \'I\'M not a moment.','2347','def-6756',1,1,1,2,4.00,2.00,'33233',72,'https://via.placeholder.com/200x200.png/00aadd?text=et',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(321,'PROVES his guilt,\' said the.','6055','def-6794',1,2,1,3,8.00,7.00,'72408',81,'https://via.placeholder.com/200x200.png/00bb55?text=culpa',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(322,'Alice, \'Have you seen the.','4481','def-5390',2,2,1,3,8.00,4.00,'57857',79,'https://via.placeholder.com/200x200.png/00ddaa?text=voluptatem',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(323,'Ann! Mary Ann!\' said the.','5448','def-8823',2,1,1,3,8.00,6.00,'35425',58,'https://via.placeholder.com/200x200.png/00eedd?text=consequatur',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(324,'Duchess was sitting next to.','8529','def-5921',2,1,1,2,4.00,9.00,'39150',77,'https://via.placeholder.com/200x200.png/002233?text=unde',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(325,'Suppress him! Pinch him! Off.','3768','def-4980',2,2,1,1,7.00,9.00,'55015',55,'https://via.placeholder.com/200x200.png/00aa55?text=ad',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(326,'Alice didn\'t think that will.','8830','def-8343',1,1,1,2,1.00,5.00,'14323',71,'https://via.placeholder.com/200x200.png/003377?text=voluptatem',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(327,'She said this she looked.','8610','def-7731',1,1,1,1,8.00,10.00,'45344',81,'https://via.placeholder.com/200x200.png/00ee77?text=voluptas',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(328,'Hatter went on, \'What\'s your.','7811','def-5348',2,2,1,1,1.00,6.00,'8190',78,'https://via.placeholder.com/200x200.png/008888?text=tempore',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(329,'THAT in a very curious to.','5476','def-5514',1,2,1,3,8.00,2.00,'47046',90,'https://via.placeholder.com/200x200.png/00bb33?text=maxime',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(330,'She soon got it out to her.','1646','def-9694',1,2,1,2,9.00,1.00,'62349',41,'https://via.placeholder.com/200x200.png/001199?text=ut',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(331,'I am to see that the way.','7356','def-3422',2,1,1,3,3.00,2.00,'35618',48,'https://via.placeholder.com/200x200.png/00ee66?text=ut',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(332,'Mock Turtle would be worth.','8589','def-2739',2,1,1,2,1.00,6.00,'59418',43,'https://via.placeholder.com/200x200.png/001166?text=ea',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(333,'It was as much as serpents.','1531','def-8143',2,2,1,1,6.00,10.00,'4963',47,'https://via.placeholder.com/200x200.png/00ffff?text=enim',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(334,'I was thinking I should be.','6812','def-8891',2,2,1,1,4.00,2.00,'90500',24,'https://via.placeholder.com/200x200.png/00dd00?text=quam',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(335,'Said the mouse doesn\'t get.','4062','def-6967',2,1,1,2,5.00,9.00,'98618',63,'https://via.placeholder.com/200x200.png/00ee88?text=vel',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(336,'Alice. \'Come on, then,\' said.','3356','def-7177',1,2,1,1,7.00,7.00,'58772',66,'https://via.placeholder.com/200x200.png/008855?text=hic',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(337,'YOUR table,\' said Alice; \'I.','3722','def-9161',2,1,1,1,7.00,2.00,'97114',22,'https://via.placeholder.com/200x200.png/00ccbb?text=temporibus',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(338,'Majesty?\' he asked. \'Begin.','7590','def-6280',2,2,1,2,7.00,5.00,'67760',50,'https://via.placeholder.com/200x200.png/009966?text=sed',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(339,'Alice, \'a great girl like.','8582','def-3372',1,1,1,3,4.00,8.00,'21644',97,'https://via.placeholder.com/200x200.png/002266?text=ratione',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(340,'Duchess. \'Everything\'s got a.','6948','def-6616',1,2,1,3,5.00,4.00,'60758',85,'https://via.placeholder.com/200x200.png/004466?text=nobis',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(341,'The Cat seemed to think this.','1217','def-5284',1,1,1,3,6.00,9.00,'42707',70,'https://via.placeholder.com/200x200.png/0099bb?text=illum',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(342,'Alice quite hungry to look.','1092','def-1162',1,1,1,1,4.00,8.00,'65079',78,'https://via.placeholder.com/200x200.png/0088ff?text=voluptatem',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(343,'The Antipathies, I think--\'.','6884','def-2963',2,2,1,2,8.00,3.00,'52129',75,'https://via.placeholder.com/200x200.png/0011aa?text=qui',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(344,'Hatter were having tea at.','8984','def-5206',2,1,1,1,3.00,7.00,'379',53,'https://via.placeholder.com/200x200.png/00bb33?text=quia',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(345,'Gryphon. \'How the creatures.','8379','def-5058',1,1,1,2,7.00,7.00,'33853',54,'https://via.placeholder.com/200x200.png/006688?text=facere',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(346,'Duchess: you\'d better leave.','2599','def-2013',1,1,1,1,4.00,3.00,'78243',64,'https://via.placeholder.com/200x200.png/0055dd?text=rerum',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(347,'Duchess. An invitation from.','7909','def-2576',1,1,1,1,5.00,6.00,'76430',71,'https://via.placeholder.com/200x200.png/00ffaa?text=explicabo',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(348,'I tell you!\' But she did not.','4430','def-7158',1,2,1,2,6.00,9.00,'78472',38,'https://via.placeholder.com/200x200.png/00ccff?text=perspiciatis',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(349,'White Rabbit: it was quite.','4622','def-8709',1,2,1,1,2.00,6.00,'82912',93,'https://via.placeholder.com/200x200.png/00ff11?text=et',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(350,'I say--that\'s the same tone.','6074','def-7789',2,2,1,1,4.00,2.00,'2243',80,'https://via.placeholder.com/200x200.png/008888?text=recusandae',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(351,'Hatter went on in the wood.','7505','def-7074',1,2,1,1,9.00,9.00,'32484',23,'https://via.placeholder.com/200x200.png/0011ff?text=reiciendis',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(352,'The first witness was the.','5809','def-8432',2,2,1,1,3.00,1.00,'12901',51,'https://via.placeholder.com/200x200.png/00bbaa?text=voluptas',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(353,'Very soon the Rabbit came.','5857','def-1946',1,2,1,3,9.00,2.00,'90656',64,'https://via.placeholder.com/200x200.png/00ff00?text=veniam',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(354,'Gryphon, with a little hot.','6629','def-7708',2,2,1,3,9.00,8.00,'28913',68,'https://via.placeholder.com/200x200.png/00ddee?text=ea',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(355,'When the procession came.','9257','def-7943',1,1,1,2,7.00,1.00,'9890',84,'https://via.placeholder.com/200x200.png/0055ee?text=minus',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(356,'Footman continued in the.','5186','def-2959',2,1,1,3,6.00,5.00,'73289',86,'https://via.placeholder.com/200x200.png/003300?text=reiciendis',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(357,'May it won\'t be raving mad.','5237','def-4159',1,2,1,1,9.00,8.00,'66922',94,'https://via.placeholder.com/200x200.png/00ff55?text=sint',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(358,'Oh, my dear Dinah! I wonder.','8183','def-3788',1,2,1,1,5.00,7.00,'8159',68,'https://via.placeholder.com/200x200.png/0099ee?text=est',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(359,'Alice, as she could see, as.','5061','def-5961',2,1,1,3,7.00,9.00,'11850',49,'https://via.placeholder.com/200x200.png/0033bb?text=sit',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(360,'Don\'t be all day to such.','2426','def-4199',1,1,1,3,8.00,7.00,'77553',66,'https://via.placeholder.com/200x200.png/00ee33?text=aut',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(361,'ME.\' \'You!\' said the Hatter.','6624','def-6156',2,1,1,1,3.00,9.00,'35761',67,'https://via.placeholder.com/200x200.png/005544?text=quaerat',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(362,'Gryphon said to the waving.','4725','def-4311',1,2,1,1,3.00,10.00,'16917',26,'https://via.placeholder.com/200x200.png/00bb77?text=natus',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(363,'WOULD put their heads down.','5699','def-4770',1,1,1,2,5.00,1.00,'16947',38,'https://via.placeholder.com/200x200.png/009988?text=distinctio',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(364,'Mock Turtle sighed deeply.','3956','def-5768',2,2,1,2,4.00,7.00,'97516',54,'https://via.placeholder.com/200x200.png/009933?text=ea',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(365,'Mock Turtle, \'Drive on, old.','8856','def-6179',1,1,1,3,6.00,9.00,'4500',65,'https://via.placeholder.com/200x200.png/0022bb?text=est',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(366,'King, \'unless it was very.','2805','def-1834',1,1,1,2,7.00,7.00,'36527',58,'https://via.placeholder.com/200x200.png/00aabb?text=quisquam',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(367,'HE was.\' \'I never thought.','5514','def-5446',2,1,1,2,8.00,9.00,'11788',32,'https://via.placeholder.com/200x200.png/009900?text=quia',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(368,'Do you think, at your age.','6349','def-1696',1,1,1,2,10.00,5.00,'14120',93,'https://via.placeholder.com/200x200.png/0055aa?text=quaerat',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(369,'For instance, suppose it.','3861','def-9511',1,2,1,1,5.00,10.00,'18114',59,'https://via.placeholder.com/200x200.png/005577?text=delectus',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(370,'Then came a little house in.','9984','def-4525',1,1,1,2,10.00,5.00,'98250',84,'https://via.placeholder.com/200x200.png/004488?text=facere',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(371,'Alice and all dripping wet.','8067','def-5768',2,2,1,3,5.00,10.00,'31560',92,'https://via.placeholder.com/200x200.png/0011aa?text=esse',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(372,'Dormouse, who was beginning.','7878','def-5202',1,1,1,2,10.00,7.00,'80923',94,'https://via.placeholder.com/200x200.png/002255?text=officiis',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(373,'There was a different person.','5771','def-4486',2,2,1,3,10.00,9.00,'76265',33,'https://via.placeholder.com/200x200.png/003399?text=aspernatur',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(374,'VERY long claws and a long.','9253','def-2354',1,2,1,3,9.00,8.00,'58535',70,'https://via.placeholder.com/200x200.png/0055bb?text=iste',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(375,'White Rabbit: it was the.','5823','def-6107',2,2,1,1,4.00,2.00,'94706',70,'https://via.placeholder.com/200x200.png/00ee11?text=voluptas',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(376,'Wonderland, though she felt.','1203','def-3294',2,2,1,3,9.00,7.00,'68411',91,'https://via.placeholder.com/200x200.png/00cc00?text=deleniti',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(377,'Dodo said, \'EVERYBODY has.','9930','def-8388',1,1,1,3,9.00,10.00,'51523',70,'https://via.placeholder.com/200x200.png/00ccaa?text=consequatur',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(378,'Gryphon. \'Of course,\' the.','4392','def-7203',1,2,1,1,2.00,6.00,'89530',26,'https://via.placeholder.com/200x200.png/0033dd?text=non',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(379,'Alice, and tried to speak.','7165','def-5576',1,2,1,3,4.00,1.00,'14539',54,'https://via.placeholder.com/200x200.png/00aa11?text=iste',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(380,'Hatter. He came in with a.','5036','def-8577',2,1,1,2,10.00,6.00,'8958',69,'https://via.placeholder.com/200x200.png/006677?text=vitae',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(381,'The soldiers were always.','5994','def-9599',2,2,1,1,6.00,9.00,'31256',36,'https://via.placeholder.com/200x200.png/00ccbb?text=saepe',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(382,'THROUGH the earth! How funny.','3746','def-2937',2,2,1,2,4.00,7.00,'7799',83,'https://via.placeholder.com/200x200.png/002299?text=consequatur',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(383,'Will you, won\'t you, won\'t.','2396','def-7373',1,1,1,3,1.00,10.00,'47394',99,'https://via.placeholder.com/200x200.png/000000?text=quos',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(384,'Alice severely. \'What are.','7002','def-3973',2,2,1,2,3.00,5.00,'88179',93,'https://via.placeholder.com/200x200.png/0000bb?text=doloribus',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(385,'After a minute or two the.','5093','def-3650',1,1,1,1,6.00,7.00,'96287',62,'https://via.placeholder.com/200x200.png/00aa88?text=sit',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(386,'Edwin and Morcar, the earls.','8306','def-4631',1,1,1,1,2.00,7.00,'38226',24,'https://via.placeholder.com/200x200.png/008899?text=sapiente',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(387,'Mouse, frowning, but very.','5166','def-3435',1,1,1,2,1.00,10.00,'60502',66,'https://via.placeholder.com/200x200.png/000033?text=in',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(388,'ME,\' said the Caterpillar.','5508','def-7004',1,1,1,1,2.00,5.00,'89300',41,'https://via.placeholder.com/200x200.png/003399?text=velit',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(389,'Mock Turtle to the Gryphon.','3248','def-5172',1,2,1,3,2.00,7.00,'63244',73,'https://via.placeholder.com/200x200.png/004477?text=architecto',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(390,'I\'m I, and--oh dear, how.','4576','def-7542',2,2,1,2,2.00,7.00,'53930',65,'https://via.placeholder.com/200x200.png/0055ff?text=voluptatem',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(391,'Nile On every golden scale!.','7985','def-9488',2,1,1,2,4.00,4.00,'82316',71,'https://via.placeholder.com/200x200.png/00dd44?text=tempora',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(392,'White Rabbit: it was only a.','9403','def-2691',2,1,1,3,9.00,3.00,'86386',22,'https://via.placeholder.com/200x200.png/006677?text=quo',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(393,'Latitude was, or Longitude.','1239','def-8465',2,2,1,1,3.00,1.00,'13312',65,'https://via.placeholder.com/200x200.png/007799?text=quia',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(394,'For instance, suppose it.','4367','def-5479',2,2,1,3,1.00,4.00,'55253',65,'https://via.placeholder.com/200x200.png/006655?text=culpa',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(395,'At this moment the door of.','7559','def-9142',2,2,1,3,10.00,3.00,'58763',71,'https://via.placeholder.com/200x200.png/009900?text=eos',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(396,'Alice, with a large ring.','5227','def-3064',2,1,1,3,9.00,1.00,'32164',77,'https://via.placeholder.com/200x200.png/0099bb?text=commodi',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(397,'Caterpillar. \'I\'m afraid.','8026','def-8796',1,2,1,1,2.00,1.00,'49080',73,'https://via.placeholder.com/200x200.png/005555?text=non',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(398,'I goes like a mouse, That he.','2410','def-7090',2,1,1,1,6.00,5.00,'21462',30,'https://via.placeholder.com/200x200.png/00bbff?text=omnis',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(399,'And yesterday things went on.','5494','def-8795',1,1,1,2,9.00,1.00,'60964',85,'https://via.placeholder.com/200x200.png/0055ff?text=id',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(400,'Alice. \'Anything you like,\'.','4785','def-4686',1,1,1,2,4.00,1.00,'93868',41,'https://via.placeholder.com/200x200.png/00bb77?text=dolore',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(401,'Mabel after all, and I don\'t.','6732','def-7387',1,2,1,2,9.00,3.00,'13034',21,'https://via.placeholder.com/200x200.png/002266?text=autem',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(402,'I should understand that.','2341','def-5710',2,1,1,1,8.00,1.00,'82303',59,'https://via.placeholder.com/200x200.png/0044bb?text=vel',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(403,'And oh, I wish you could see.','9894','def-9704',1,2,1,1,3.00,5.00,'78801',45,'https://via.placeholder.com/200x200.png/005544?text=et',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(404,'Dodo, pointing to Alice an.','2741','def-7098',2,2,1,1,4.00,1.00,'14334',27,'https://via.placeholder.com/200x200.png/005511?text=vero',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(405,'Cat. \'Do you know what \"it\".','8876','def-9665',1,2,1,2,4.00,8.00,'80812',27,'https://via.placeholder.com/200x200.png/005533?text=cupiditate',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(406,'Turtle.\' These words were.','7133','def-7711',1,2,1,3,6.00,4.00,'77806',97,'https://via.placeholder.com/200x200.png/00bbbb?text=qui',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(407,'She hastily put down her.','2481','def-9214',2,1,1,1,5.00,2.00,'98394',44,'https://via.placeholder.com/200x200.png/00bbdd?text=neque',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(408,'I then? Tell me that first.','2260','def-5063',2,2,1,1,6.00,8.00,'35768',90,'https://via.placeholder.com/200x200.png/0033aa?text=expedita',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(409,'Sir, With no jury or judge.','9441','def-7877',1,1,1,1,6.00,4.00,'99379',62,'https://via.placeholder.com/200x200.png/008800?text=aliquid',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(410,'I\'ll look first,\' she said.','2734','def-8361',1,1,1,2,3.00,3.00,'29270',42,'https://via.placeholder.com/200x200.png/0033ee?text=voluptatem',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(411,'THAT. Then again--\"BEFORE.','6181','def-3472',2,2,1,3,7.00,4.00,'5152',71,'https://via.placeholder.com/200x200.png/009966?text=quos',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(412,'Seven flung down his cheeks.','2513','def-7484',1,2,1,1,4.00,2.00,'26480',27,'https://via.placeholder.com/200x200.png/001100?text=voluptates',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(413,'Latin Grammar, \'A mouse--of.','5537','def-7949',1,1,1,1,8.00,8.00,'2112',54,'https://via.placeholder.com/200x200.png/00ee00?text=qui',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(414,'CHAPTER IV. The Rabbit Sends.','6282','def-7118',2,1,1,1,9.00,4.00,'74541',46,'https://via.placeholder.com/200x200.png/00cc22?text=explicabo',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(415,'Him, and ourselves, and it.','9563','def-8616',1,1,1,1,8.00,5.00,'25267',21,'https://via.placeholder.com/200x200.png/0044cc?text=ut',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(416,'Let me think: was I the same.','3006','def-1694',1,1,1,3,2.00,5.00,'98949',55,'https://via.placeholder.com/200x200.png/002200?text=qui',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(417,'I don\'t take this young lady.','4141','def-9282',2,2,1,1,10.00,3.00,'12168',64,'https://via.placeholder.com/200x200.png/001111?text=tenetur',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(418,'King: \'leave out that one of.','1407','def-2154',2,1,1,2,6.00,5.00,'83249',37,'https://via.placeholder.com/200x200.png/008822?text=nam',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(419,'As they walked off together.','9659','def-3965',2,1,1,3,10.00,4.00,'56642',79,'https://via.placeholder.com/200x200.png/00ffdd?text=fuga',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(420,'Duchess, \'as pigs have to.','3149','def-9110',1,1,1,3,1.00,8.00,'29469',84,'https://via.placeholder.com/200x200.png/00bb33?text=nobis',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(421,'Mystery,\' the Mock Turtle to.','5921','def-9366',1,2,1,2,8.00,8.00,'95218',64,'https://via.placeholder.com/200x200.png/00eedd?text=optio',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(422,'He says it kills all the.','2556','def-6791',2,1,1,1,3.00,3.00,'76808',72,'https://via.placeholder.com/200x200.png/00cc44?text=modi',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(423,'The pepper when he sneezes.','9813','def-6356',1,2,1,2,1.00,3.00,'91521',51,'https://via.placeholder.com/200x200.png/00aadd?text=dolores',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(424,'Alice, very earnestly. \'I\'ve.','4112','def-1847',1,1,1,2,4.00,4.00,'38511',68,'https://via.placeholder.com/200x200.png/00dd88?text=vero',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(425,'I shall remember it in a.','2864','def-4798',1,1,1,1,4.00,4.00,'87246',65,'https://via.placeholder.com/200x200.png/0022cc?text=veritatis',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(426,'Mock Turtle replied; \'and.','5296','def-9371',1,1,1,2,6.00,10.00,'27145',58,'https://via.placeholder.com/200x200.png/0033ff?text=et',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(427,'Queen merely remarking that.','8503','def-6895',1,2,1,2,8.00,9.00,'5407',96,'https://via.placeholder.com/200x200.png/0044aa?text=tempore',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(428,'The poor little thing howled.','3968','def-2557',1,2,1,1,8.00,5.00,'39176',77,'https://via.placeholder.com/200x200.png/005577?text=illo',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(429,'I think I should think it.','3730','def-6201',1,2,1,3,9.00,5.00,'34666',59,'https://via.placeholder.com/200x200.png/004422?text=quod',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(430,'I\'ve kept her eyes anxiously.','2392','def-7094',2,2,1,3,9.00,8.00,'31379',34,'https://via.placeholder.com/200x200.png/00bb11?text=deserunt',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(431,'King added in an offended.','2751','def-5018',1,1,1,2,5.00,5.00,'28715',83,'https://via.placeholder.com/200x200.png/005533?text=sit',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(432,'Rabbit actually TOOK A WATCH.','6222','def-2296',1,2,1,3,8.00,8.00,'85913',84,'https://via.placeholder.com/200x200.png/009900?text=doloribus',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(433,'Seven flung down his face.','9256','def-2295',1,1,1,2,10.00,6.00,'72994',64,'https://via.placeholder.com/200x200.png/0088ee?text=necessitatibus',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(434,'Alice went on, yawning and.','7316','def-9451',1,2,1,3,4.00,7.00,'45452',92,'https://via.placeholder.com/200x200.png/00aa11?text=laborum',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(435,'Atheling to meet William and.','4399','def-9254',1,2,1,2,9.00,1.00,'25432',100,'https://via.placeholder.com/200x200.png/009999?text=cumque',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(436,'HAVE their tails in their.','9113','def-5493',2,1,1,1,10.00,3.00,'35462',32,'https://via.placeholder.com/200x200.png/005555?text=molestiae',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(437,'Alice put down the chimney.','6247','def-6654',1,1,1,1,8.00,7.00,'91687',58,'https://via.placeholder.com/200x200.png/0055aa?text=qui',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(438,'Hatter. \'Stolen!\' the King.','2430','def-3595',1,1,1,1,4.00,4.00,'16729',26,'https://via.placeholder.com/200x200.png/001155?text=quia',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(439,'ARE a simpleton.\' Alice did.','9746','def-6507',2,1,1,1,4.00,3.00,'70345',21,'https://via.placeholder.com/200x200.png/00aa99?text=consequatur',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(440,'The first question of course.','3003','def-7396',1,2,1,1,7.00,9.00,'62869',91,'https://via.placeholder.com/200x200.png/003300?text=sint',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(441,'I goes like a telescope! I.','7949','def-1468',2,2,1,2,9.00,7.00,'91422',97,'https://via.placeholder.com/200x200.png/00ff44?text=autem',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(442,'Said cunning old Fury: \"I\'ll.','8793','def-1808',1,1,1,3,5.00,2.00,'1844',29,'https://via.placeholder.com/200x200.png/00ddff?text=minima',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(443,'Dormouse say?\' one of these.','4748','def-9870',1,2,1,2,2.00,1.00,'79230',98,'https://via.placeholder.com/200x200.png/002299?text=et',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(444,'Alice went on, \'--likely to.','9674','def-9543',1,1,1,2,1.00,7.00,'88785',85,'https://via.placeholder.com/200x200.png/000088?text=sed',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(445,'Alice\'s first thought was.','3915','def-6584',2,2,1,3,3.00,2.00,'16630',92,'https://via.placeholder.com/200x200.png/002200?text=iste',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(446,'I learn music.\' \'Ah! that.','7939','def-5083',1,2,1,3,3.00,6.00,'12464',23,'https://via.placeholder.com/200x200.png/00bb00?text=laudantium',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(447,'You grant that?\' \'I suppose.','6039','def-4431',2,2,1,2,3.00,10.00,'76531',85,'https://via.placeholder.com/200x200.png/00bbff?text=pariatur',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(448,'Alice, and she walked sadly.','9519','def-2041',2,2,1,1,5.00,7.00,'39433',29,'https://via.placeholder.com/200x200.png/006611?text=assumenda',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(449,'Queen. \'You make me smaller.','4680','def-9157',1,2,1,1,6.00,8.00,'48004',59,'https://via.placeholder.com/200x200.png/007755?text=id',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(450,'Time!\' \'Perhaps not,\' Alice.','8713','def-2202',1,1,1,1,1.00,4.00,'96455',31,'https://via.placeholder.com/200x200.png/00eedd?text=qui',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(451,'Alice waited a little, half.','7111','def-9601',1,1,1,3,6.00,8.00,'59633',35,'https://via.placeholder.com/200x200.png/0088ee?text=molestias',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(452,'Just then she noticed that.','8179','def-1129',1,2,1,2,5.00,9.00,'98408',89,'https://via.placeholder.com/200x200.png/009933?text=dicta',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(453,'Alice, with a soldier on.','8467','def-3399',1,2,1,1,2.00,7.00,'10426',39,'https://via.placeholder.com/200x200.png/0044dd?text=voluptatem',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(454,'I\'ve got to come down the.','3427','def-7276',1,1,1,2,5.00,9.00,'45613',54,'https://via.placeholder.com/200x200.png/00ddcc?text=recusandae',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(455,'He was an old Turtle--we.','4334','def-4658',1,2,1,1,1.00,5.00,'66159',77,'https://via.placeholder.com/200x200.png/007733?text=iusto',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(456,'King said, for about the.','7907','def-8654',2,2,1,3,8.00,7.00,'117',31,'https://via.placeholder.com/200x200.png/00ee00?text=voluptatum',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(457,'Caterpillar called after.','5484','def-9345',1,1,1,2,4.00,3.00,'6376',56,'https://via.placeholder.com/200x200.png/00ee55?text=et',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(458,'And she went nearer to watch.','4872','def-6714',2,1,1,3,3.00,10.00,'54658',99,'https://via.placeholder.com/200x200.png/00bb55?text=repellat',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(459,'The Pool of Tears \'Curiouser.','6325','def-1006',1,2,1,3,6.00,7.00,'11308',81,'https://via.placeholder.com/200x200.png/00cc66?text=ratione',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(460,'Caterpillar. \'Well, perhaps.','1272','def-6141',1,1,1,1,3.00,4.00,'19141',95,'https://via.placeholder.com/200x200.png/0066cc?text=quibusdam',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(461,'This was quite out of the.','6236','def-7805',2,1,1,2,6.00,3.00,'53071',51,'https://via.placeholder.com/200x200.png/0011bb?text=voluptas',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(462,'All the time they had at the.','6545','def-6590',1,1,1,3,9.00,1.00,'78010',20,'https://via.placeholder.com/200x200.png/00aa66?text=voluptas',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(463,'She waited for a long and a.','9278','def-5960',1,1,1,1,1.00,2.00,'81638',27,'https://via.placeholder.com/200x200.png/00bb22?text=possimus',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(464,'Cat, \'if you don\'t know what.','6378','def-7304',2,1,1,2,5.00,5.00,'51728',71,'https://via.placeholder.com/200x200.png/00bbaa?text=blanditiis',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(465,'Besides, SHE\'S she, and I\'m.','8014','def-2234',2,2,1,1,2.00,1.00,'67238',75,'https://via.placeholder.com/200x200.png/00bbbb?text=itaque',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(466,'I\'m not particular as to.','8426','def-9073',2,1,1,2,7.00,2.00,'76272',63,'https://via.placeholder.com/200x200.png/009900?text=quia',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(467,'King eagerly, and he says.','7441','def-3806',2,2,1,2,1.00,7.00,'99439',35,'https://via.placeholder.com/200x200.png/00aabb?text=et',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(468,'Alice said nothing; she had.','8875','def-6938',2,1,1,3,2.00,6.00,'92893',73,'https://via.placeholder.com/200x200.png/0044cc?text=aperiam',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(469,'Alice joined the procession.','7388','def-7086',1,2,1,1,3.00,8.00,'89025',43,'https://via.placeholder.com/200x200.png/001100?text=ut',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(470,'King said, for about the.','5420','def-2463',2,1,1,3,8.00,5.00,'66535',36,'https://via.placeholder.com/200x200.png/0099dd?text=laudantium',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(471,'The first witness was the.','8209','def-3131',2,1,1,3,8.00,9.00,'17712',92,'https://via.placeholder.com/200x200.png/00aaee?text=quae',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(472,'The cook threw a frying-pan.','3451','def-6029',2,2,1,1,8.00,10.00,'34512',63,'https://via.placeholder.com/200x200.png/008877?text=fuga',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(473,'French mouse, come over with.','4374','def-1836',2,1,1,1,5.00,9.00,'64465',65,'https://via.placeholder.com/200x200.png/004488?text=aut',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(474,'SAID was, \'Why is a raven.','6081','def-5858',2,2,1,1,10.00,5.00,'29959',56,'https://via.placeholder.com/200x200.png/0099ff?text=fuga',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(475,'Alice replied very politely.','3216','def-7238',1,2,1,3,1.00,4.00,'51397',99,'https://via.placeholder.com/200x200.png/0044bb?text=ex',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(476,'Bill!\' then the Mock Turtle.','5352','def-9818',1,2,1,2,8.00,10.00,'41189',55,'https://via.placeholder.com/200x200.png/0044ff?text=rerum',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(477,'The Footman seemed to be.','4983','def-2881',2,2,1,1,4.00,4.00,'89881',48,'https://via.placeholder.com/200x200.png/002288?text=atque',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(478,'GAVE HER ONE, THEY GAVE HIM.','3781','def-7430',1,2,1,3,7.00,1.00,'69853',56,'https://via.placeholder.com/200x200.png/00ff77?text=corrupti',1,'System@email.com','2023-12-27 12:12:48','2023-12-27 12:12:48'),(479,'Gryphon added \'Come, let\'s.','9109','def-4415',2,1,1,2,10.00,6.00,'42075',49,'https://via.placeholder.com/200x200.png/007788?text=ex',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(480,'I\'m sure she\'s the best of.','6044','def-4913',1,2,1,3,6.00,7.00,'97102',94,'https://via.placeholder.com/200x200.png/0022ff?text=modi',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(481,'Where CAN I have dropped.','7217','def-2688',2,1,1,2,1.00,5.00,'19465',67,'https://via.placeholder.com/200x200.png/0011dd?text=aut',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(482,'Pigeon; \'but I must have.','2637','def-4529',2,2,1,1,8.00,6.00,'78954',70,'https://via.placeholder.com/200x200.png/00ff55?text=dolorem',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(483,'She was looking about for.','3768','def-3174',2,1,1,1,8.00,6.00,'76472',21,'https://via.placeholder.com/200x200.png/007788?text=fugiat',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(484,'Oh dear, what nonsense I\'m.','7926','def-3734',1,1,1,3,3.00,2.00,'19520',61,'https://via.placeholder.com/200x200.png/000022?text=voluptatem',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(485,'It quite makes my forehead.','6280','def-9084',2,2,1,2,1.00,5.00,'42585',47,'https://via.placeholder.com/200x200.png/0088ee?text=in',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(486,'Though they were trying to.','9775','def-4432',2,2,1,3,9.00,8.00,'52154',51,'https://via.placeholder.com/200x200.png/00dd33?text=aut',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(487,'And how odd the directions.','6933','def-8291',1,2,1,1,5.00,4.00,'21952',49,'https://via.placeholder.com/200x200.png/00dd11?text=iste',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(488,'YOU must cross-examine THIS.','9441','def-1672',2,2,1,2,8.00,6.00,'51740',80,'https://via.placeholder.com/200x200.png/009955?text=sed',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(489,'The Antipathies, I think--\'.','6449','def-8807',2,2,1,1,6.00,1.00,'20244',99,'https://via.placeholder.com/200x200.png/0077ff?text=amet',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(490,'Dodo solemnly, rising to its.','8478','def-6971',1,2,1,2,3.00,5.00,'28272',67,'https://via.placeholder.com/200x200.png/000000?text=quia',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(491,'Hatter, with an M?\' said.','5687','def-4650',1,2,1,1,1.00,9.00,'25419',25,'https://via.placeholder.com/200x200.png/003355?text=veritatis',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(492,'There was a good thing!\' she.','8545','def-9942',1,2,1,2,5.00,8.00,'38917',100,'https://via.placeholder.com/200x200.png/0088aa?text=delectus',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(493,'Queen to-day?\' \'I should.','6211','def-7046',1,2,1,3,6.00,2.00,'5848',27,'https://via.placeholder.com/200x200.png/001144?text=cupiditate',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(494,'Gryphon. \'Of course,\' the.','2689','def-4896',1,2,1,2,1.00,10.00,'22051',21,'https://via.placeholder.com/200x200.png/001166?text=provident',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(495,'Alice could not think of.','9889','def-9589',1,2,1,1,5.00,3.00,'22437',73,'https://via.placeholder.com/200x200.png/00ff88?text=soluta',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(496,'PLEASE mind what you\'re at!\".','1547','def-2763',2,1,1,1,3.00,5.00,'70270',74,'https://via.placeholder.com/200x200.png/005500?text=itaque',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(497,'After a minute or two she.','9725','def-8911',1,1,1,1,3.00,10.00,'39073',43,'https://via.placeholder.com/200x200.png/00cc66?text=repudiandae',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(498,'Pigeon; \'but I must have.','3989','def-1975',2,1,1,2,1.00,6.00,'47817',22,'https://via.placeholder.com/200x200.png/0000dd?text=iure',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(499,'Pigeon. \'I can tell you just.','5478','def-1649',2,1,1,1,3.00,7.00,'62495',92,'https://via.placeholder.com/200x200.png/006633?text=unde',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(500,'Dormouse followed him: the.','1508','def-3639',2,1,1,1,3.00,10.00,'86102',40,'https://via.placeholder.com/200x200.png/00aa88?text=nemo',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(501,'Hatter. \'I told you that.\'.','2170','def-6498',2,2,1,2,10.00,1.00,'16259',28,'https://via.placeholder.com/200x200.png/0055ff?text=sunt',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(502,'Dodo could not help bursting.','3207','def-8681',2,2,1,3,2.00,10.00,'93127',79,'https://via.placeholder.com/200x200.png/009944?text=id',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(503,'Duchess: \'what a clear way.','6720','def-4362',1,2,1,3,6.00,5.00,'18951',75,'https://via.placeholder.com/200x200.png/0088aa?text=ut',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(504,'Gryphon, the squeaking of.','5525','def-2845',1,2,1,2,3.00,7.00,'93865',78,'https://via.placeholder.com/200x200.png/005599?text=velit',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(505,'And argued each case with.','1461','def-6413',2,2,1,2,9.00,4.00,'93054',20,'https://via.placeholder.com/200x200.png/00eeff?text=consequuntur',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(506,'Hatter was the matter on.','4383','def-2955',2,2,1,3,1.00,10.00,'6270',49,'https://via.placeholder.com/200x200.png/002200?text=est',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(507,'T!\' said the cook. The King.','7887','def-1289',1,2,1,2,4.00,9.00,'17651',24,'https://via.placeholder.com/200x200.png/00bb99?text=quae',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(508,'Because he knows it teases.\'.','1217','def-2893',1,1,1,2,10.00,7.00,'60456',59,'https://via.placeholder.com/200x200.png/000033?text=dolores',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(509,'Alice, feeling very curious.','3318','def-2985',2,2,1,3,8.00,1.00,'92185',23,'https://via.placeholder.com/200x200.png/001199?text=molestiae',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(510,'Bill, the Lizard) could not.','2036','def-8265',2,2,1,2,2.00,9.00,'39445',97,'https://via.placeholder.com/200x200.png/007766?text=saepe',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(511,'Alice, that she had put the.','3747','def-5350',2,2,1,3,8.00,9.00,'5460',75,'https://via.placeholder.com/200x200.png/00ccdd?text=sed',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(512,'And pour the waters of the.','3503','def-8715',2,2,1,3,10.00,1.00,'66516',36,'https://via.placeholder.com/200x200.png/00aaff?text=molestias',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(513,'Hatter and the little glass.','3415','def-7607',1,1,1,2,5.00,6.00,'73553',39,'https://via.placeholder.com/200x200.png/00ffcc?text=dolor',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(514,'However, \'jury-men\' would.','9749','def-7978',2,2,1,1,7.00,3.00,'35010',95,'https://via.placeholder.com/200x200.png/0044dd?text=eveniet',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(515,'Caterpillar. \'Is that the.','3214','def-9253',1,1,1,3,10.00,3.00,'38954',100,'https://via.placeholder.com/200x200.png/0044ff?text=eum',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(516,'Alice desperately: \'he\'s.','4330','def-4737',2,1,1,1,9.00,8.00,'21860',100,'https://via.placeholder.com/200x200.png/0077ee?text=enim',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(517,'I\'ll go round a deal too.','4797','def-4238',2,2,1,3,9.00,8.00,'45632',20,'https://via.placeholder.com/200x200.png/005522?text=velit',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(518,'The Dormouse slowly opened.','3699','def-2604',2,1,1,1,5.00,10.00,'10181',99,'https://via.placeholder.com/200x200.png/00cc00?text=quas',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(519,'Mock Turtle, \'Drive on, old.','3553','def-8378',2,2,1,1,1.00,7.00,'88633',36,'https://via.placeholder.com/200x200.png/0033bb?text=laudantium',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(520,'Queen\'s absence, and were.','2900','def-1649',2,2,1,1,2.00,8.00,'20388',32,'https://via.placeholder.com/200x200.png/00ff55?text=qui',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(521,'Alice to herself, as she did.','7870','def-8893',2,1,1,3,3.00,4.00,'72466',76,'https://via.placeholder.com/200x200.png/00dd33?text=expedita',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(522,'Queen said severely \'Who is.','4142','def-3954',1,1,1,2,2.00,7.00,'18778',59,'https://via.placeholder.com/200x200.png/00aa55?text=molestiae',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(523,'Lory, as soon as she spoke.','8291','def-6931',1,2,1,2,6.00,2.00,'67129',35,'https://via.placeholder.com/200x200.png/00eeff?text=dolor',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(524,'And it\'ll fetch things when.','3474','def-2435',2,1,1,3,1.00,6.00,'96814',55,'https://via.placeholder.com/200x200.png/0077ff?text=aut',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(525,'I do it again and again.\'.','9855','def-2400',2,2,1,3,1.00,2.00,'57182',27,'https://via.placeholder.com/200x200.png/0099ee?text=itaque',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(526,'The Dormouse had closed its.','5511','def-4635',1,1,1,1,4.00,1.00,'52334',24,'https://via.placeholder.com/200x200.png/0044cc?text=velit',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(527,'Alice. \'You must be,\' said.','1604','def-4905',1,2,1,3,10.00,2.00,'40005',77,'https://via.placeholder.com/200x200.png/001122?text=id',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(528,'Hatter, \'you wouldn\'t talk.','6120','def-5411',2,1,1,3,1.00,7.00,'85983',85,'https://via.placeholder.com/200x200.png/004422?text=animi',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(529,'Mock Turtle said: \'I\'m too.','1118','def-7004',2,1,1,3,10.00,6.00,'48987',48,'https://via.placeholder.com/200x200.png/00ff33?text=ut',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(530,'Alice to herself. (Alice had.','7088','def-4409',1,2,1,3,8.00,5.00,'98909',53,'https://via.placeholder.com/200x200.png/001155?text=ut',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(531,'Alice thought to herself.','6407','def-8680',2,1,1,3,5.00,9.00,'83119',81,'https://via.placeholder.com/200x200.png/00aa11?text=perspiciatis',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(532,'There was a good way off.','1051','def-9374',2,1,1,3,8.00,5.00,'51341',61,'https://via.placeholder.com/200x200.png/00ee55?text=officiis',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(533,'Alice could think of any.','1996','def-9484',2,2,1,3,9.00,8.00,'34664',26,'https://via.placeholder.com/200x200.png/00ee00?text=ipsum',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(534,'Mock Turtle, \'they--you\'ve.','4305','def-4003',2,1,1,3,5.00,9.00,'78860',53,'https://via.placeholder.com/200x200.png/002288?text=suscipit',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(535,'Gryphon, and the sounds will.','7693','def-5517',1,2,1,2,8.00,3.00,'88411',79,'https://via.placeholder.com/200x200.png/0055dd?text=doloribus',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(536,'Alice, (she had grown so.','6354','def-9928',2,1,1,2,7.00,4.00,'3230',86,'https://via.placeholder.com/200x200.png/004455?text=itaque',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(537,'Alice would not join the.','7988','def-7888',1,1,1,1,5.00,7.00,'10859',37,'https://via.placeholder.com/200x200.png/009911?text=magni',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(538,'Dodo solemnly presented the.','6955','def-2296',1,1,1,3,4.00,3.00,'9898',86,'https://via.placeholder.com/200x200.png/0066dd?text=officiis',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(539,'Alice ventured to say. \'What.','8528','def-8052',1,1,1,3,6.00,8.00,'8989',60,'https://via.placeholder.com/200x200.png/00ffee?text=eaque',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(540,'For he can thoroughly enjoy.','5448','def-4596',2,1,1,1,4.00,1.00,'52032',96,'https://via.placeholder.com/200x200.png/003377?text=quia',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(541,'Alice opened the door and.','7872','def-4367',1,1,1,2,8.00,6.00,'11685',34,'https://via.placeholder.com/200x200.png/00bb33?text=neque',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(542,'I should think!\' (Dinah was.','8430','def-6448',1,2,1,2,7.00,8.00,'33823',96,'https://via.placeholder.com/200x200.png/00cc00?text=iste',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(543,'Exactly as we needn\'t try to.','4005','def-3622',2,2,1,2,2.00,3.00,'56840',21,'https://via.placeholder.com/200x200.png/000011?text=impedit',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(544,'Gryphon went on, \'\"--found.','4222','def-9898',1,1,1,3,3.00,4.00,'11872',80,'https://via.placeholder.com/200x200.png/0088dd?text=dolor',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(545,'Duchess, \'as pigs have to go.','2942','def-8655',1,2,1,3,6.00,6.00,'68845',66,'https://via.placeholder.com/200x200.png/009922?text=explicabo',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(546,'Gryphon, \'you first form.','2353','def-9534',1,2,1,2,8.00,3.00,'9267',63,'https://via.placeholder.com/200x200.png/007766?text=saepe',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(547,'And how odd the directions.','3841','def-2651',1,1,1,3,5.00,1.00,'39672',35,'https://via.placeholder.com/200x200.png/0099dd?text=enim',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(548,'I mean what I could not help.','4374','def-6838',2,1,1,2,6.00,10.00,'22752',51,'https://via.placeholder.com/200x200.png/0055aa?text=et',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(549,'Alice was a large arm-chair.','7218','def-3514',1,2,1,3,4.00,6.00,'42436',63,'https://via.placeholder.com/200x200.png/0044ee?text=placeat',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(550,'I think?\' he said in a very.','1444','def-5366',1,1,1,1,8.00,3.00,'42162',39,'https://via.placeholder.com/200x200.png/009911?text=nulla',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(551,'So they couldn\'t get them.','3545','def-2030',1,1,1,3,5.00,5.00,'9458',33,'https://via.placeholder.com/200x200.png/000000?text=ducimus',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(552,'She was walking by the time.','2383','def-5300',2,1,1,2,1.00,8.00,'93820',70,'https://via.placeholder.com/200x200.png/006688?text=quas',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(553,'Oh, my dear Dinah! I wonder.','8307','def-6611',1,2,1,1,9.00,2.00,'59745',78,'https://via.placeholder.com/200x200.png/0077dd?text=sed',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(554,'I should think you\'ll feel.','9648','def-3053',2,1,1,1,5.00,3.00,'81048',96,'https://via.placeholder.com/200x200.png/0066dd?text=voluptatibus',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(555,'Hatter, with an anxious look.','2765','def-3682',2,1,1,1,3.00,6.00,'85376',37,'https://via.placeholder.com/200x200.png/003311?text=vero',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(556,'I\'ve offended it again!\' For.','9325','def-5188',2,2,1,3,10.00,2.00,'47134',34,'https://via.placeholder.com/200x200.png/002211?text=quis',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(557,'First, because I\'m on the.','4071','def-4095',1,1,1,1,2.00,5.00,'50604',61,'https://via.placeholder.com/200x200.png/008899?text=delectus',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(558,'Queen of Hearts, she made.','4837','def-2494',2,1,1,2,3.00,5.00,'87433',71,'https://via.placeholder.com/200x200.png/0088dd?text=corporis',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(559,'ALL RETURNED FROM HIM TO.','5325','def-1201',1,1,1,2,6.00,5.00,'67968',37,'https://via.placeholder.com/200x200.png/0044dd?text=et',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(560,'Soup of the shelves as she.','6087','def-9425',2,1,1,2,3.00,8.00,'29996',93,'https://via.placeholder.com/200x200.png/00ee55?text=dolores',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(561,'Dodo, a Lory and an old Crab.','2325','def-1997',2,2,1,1,4.00,7.00,'37990',32,'https://via.placeholder.com/200x200.png/0055dd?text=dolores',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(562,'Five and Seven said nothing.','7647','def-4122',1,1,1,3,3.00,5.00,'67901',65,'https://via.placeholder.com/200x200.png/00eebb?text=dolores',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(563,'Alice, a good deal on where.','4063','def-6202',2,1,1,3,1.00,9.00,'29848',82,'https://via.placeholder.com/200x200.png/0000cc?text=qui',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(564,'Five! Always lay the blame.','8695','def-8958',2,1,1,2,4.00,8.00,'96289',97,'https://via.placeholder.com/200x200.png/0033aa?text=perferendis',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(565,'I chose,\' the Duchess began.','5426','def-9631',2,2,1,1,6.00,10.00,'32410',26,'https://via.placeholder.com/200x200.png/00dd55?text=ut',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(566,'It was so much frightened.','4983','def-6756',1,2,1,1,10.00,6.00,'72455',26,'https://via.placeholder.com/200x200.png/001100?text=neque',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(567,'Besides, SHE\'S she, and I\'m.','6166','def-1676',1,2,1,3,1.00,3.00,'68261',78,'https://via.placeholder.com/200x200.png/00dd00?text=quia',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(568,'I know all sorts of little.','4275','def-6244',1,2,1,3,1.00,4.00,'21428',49,'https://via.placeholder.com/200x200.png/00cc55?text=aliquam',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(569,'Mock Turtle replied; \'and.','1676','def-3343',1,2,1,1,1.00,2.00,'41826',31,'https://via.placeholder.com/200x200.png/002211?text=sequi',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(570,'Alice and all that,\' he said.','3524','def-7414',2,2,1,3,5.00,3.00,'52618',49,'https://via.placeholder.com/200x200.png/00aaee?text=tempora',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(571,'The Antipathies, I think--\'.','9952','def-5317',2,2,1,2,2.00,8.00,'92802',90,'https://via.placeholder.com/200x200.png/00aa55?text=culpa',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(572,'I wonder what you\'re at!\".','2968','def-3314',1,1,1,3,5.00,5.00,'91388',92,'https://via.placeholder.com/200x200.png/0011dd?text=et',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(573,'It was all finished, the.','5753','def-9281',2,1,1,1,5.00,2.00,'53463',89,'https://via.placeholder.com/200x200.png/00ee11?text=voluptas',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(574,'The Knave did so, and were.','8535','def-1547',1,1,1,1,7.00,9.00,'7556',62,'https://via.placeholder.com/200x200.png/009955?text=pariatur',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(575,'Let this be a lesson to you.','5360','def-1190',2,1,1,1,1.00,9.00,'8202',62,'https://via.placeholder.com/200x200.png/0088ff?text=a',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(576,'I suppose, by being drowned.','8802','def-7937',2,1,1,2,3.00,9.00,'34708',34,'https://via.placeholder.com/200x200.png/00cc44?text=praesentium',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(577,'The Dormouse slowly opened.','4047','def-9895',2,1,1,1,10.00,1.00,'9755',53,'https://via.placeholder.com/200x200.png/00ccdd?text=quis',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(578,'Why, there\'s hardly enough.','7774','def-8168',1,2,1,3,4.00,10.00,'21372',66,'https://via.placeholder.com/200x200.png/0000cc?text=enim',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(579,'White Rabbit, \'but it sounds.','1303','def-3498',1,1,1,3,4.00,3.00,'13998',46,'https://via.placeholder.com/200x200.png/0055ee?text=nisi',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(580,'Alice as he said in a very.','4340','def-3550',2,1,1,3,6.00,4.00,'47779',91,'https://via.placeholder.com/200x200.png/00bb77?text=pariatur',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(581,'However, this bottle was a.','5218','def-5847',1,2,1,1,2.00,7.00,'31234',97,'https://via.placeholder.com/200x200.png/003344?text=et',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(582,'SHE, of course,\' the Mock.','7075','def-5062',1,1,1,3,10.00,7.00,'40765',97,'https://via.placeholder.com/200x200.png/00cc22?text=laudantium',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(583,'Dinah my dear! Let this be a.','2871','def-3986',2,1,1,2,9.00,6.00,'93339',38,'https://via.placeholder.com/200x200.png/00cc77?text=dolor',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(584,'Beautiful, beautiful Soup!\'.','5548','def-7506',1,2,1,1,3.00,6.00,'94668',20,'https://via.placeholder.com/200x200.png/000066?text=dolorem',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(585,'Do you think, at your age.','5050','def-6901',2,2,1,2,3.00,5.00,'50015',56,'https://via.placeholder.com/200x200.png/0077cc?text=occaecati',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(586,'Footman. \'That\'s the most.','8191','def-7808',1,1,1,2,5.00,4.00,'6910',75,'https://via.placeholder.com/200x200.png/00bbff?text=dolore',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(587,'Would not, could not, would.','6699','def-7981',2,1,1,1,5.00,10.00,'79320',73,'https://via.placeholder.com/200x200.png/00dd99?text=necessitatibus',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(588,'Alice, \'they\'re sure to make.','5941','def-5950',1,1,1,2,3.00,3.00,'50669',98,'https://via.placeholder.com/200x200.png/0077ff?text=blanditiis',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(589,'March Hare moved into the.','9732','def-7806',2,2,1,3,5.00,1.00,'77331',41,'https://via.placeholder.com/200x200.png/006699?text=eveniet',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(590,'Alice. \'Off with her face.','9858','def-3420',2,1,1,1,10.00,6.00,'84687',82,'https://via.placeholder.com/200x200.png/00aa22?text=libero',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(591,'King. \'Shan\'t,\' said the.','6529','def-3730',2,1,1,2,10.00,2.00,'74551',94,'https://via.placeholder.com/200x200.png/00ccaa?text=pariatur',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(592,'Jack-in-the-box, and up the.','2948','def-2017',1,2,1,2,7.00,9.00,'25991',22,'https://via.placeholder.com/200x200.png/003366?text=sint',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(593,'Alice looked at Two. Two.','7931','def-2119',2,1,1,1,2.00,2.00,'90138',87,'https://via.placeholder.com/200x200.png/0044dd?text=dolor',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(594,'Laughing and Grief, they.','7100','def-7571',1,1,1,1,7.00,8.00,'83882',22,'https://via.placeholder.com/200x200.png/0022ee?text=itaque',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(595,'King eagerly, and he checked.','5718','def-9176',2,1,1,2,10.00,10.00,'1975',91,'https://via.placeholder.com/200x200.png/0088cc?text=porro',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(596,'Alice, very earnestly. \'I\'ve.','4266','def-8604',1,1,1,1,10.00,10.00,'61782',32,'https://via.placeholder.com/200x200.png/00ffaa?text=nostrum',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(597,'I think you\'d take a fancy.','2720','def-3869',2,2,1,2,4.00,2.00,'26074',22,'https://via.placeholder.com/200x200.png/0077bb?text=laboriosam',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(598,'Queen, who were lying round.','6867','def-2298',2,2,1,2,9.00,3.00,'67964',91,'https://via.placeholder.com/200x200.png/003311?text=molestiae',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(599,'Queen\'s hedgehog just now.','3746','def-8323',2,1,1,2,4.00,1.00,'88264',91,'https://via.placeholder.com/200x200.png/00aa99?text=omnis',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(600,'Suppress him! Pinch him! Off.','4305','def-8851',2,1,1,2,8.00,9.00,'32839',96,'https://via.placeholder.com/200x200.png/0044aa?text=aut',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(601,'And then a voice outside.','8655','def-4160',1,2,1,2,4.00,5.00,'90916',66,'https://via.placeholder.com/200x200.png/000022?text=qui',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(602,'Rabbit actually TOOK A WATCH.','3921','def-3412',2,2,1,1,2.00,2.00,'77216',63,'https://via.placeholder.com/200x200.png/0099aa?text=sit',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(603,'Queen of Hearts, who only.','5120','def-3171',2,2,1,1,10.00,1.00,'52551',27,'https://via.placeholder.com/200x200.png/00ffdd?text=sunt',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(604,'I should think you can find.','5163','def-6434',2,1,1,1,10.00,7.00,'25098',55,'https://via.placeholder.com/200x200.png/006644?text=quia',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(605,'The Hatter opened his eyes.','8129','def-8226',2,2,1,3,10.00,2.00,'14263',40,'https://via.placeholder.com/200x200.png/0099aa?text=distinctio',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(606,'King, the Queen, who was.','9916','def-2070',1,1,1,3,10.00,7.00,'93621',40,'https://via.placeholder.com/200x200.png/0044ff?text=consequatur',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(607,'Queen, the royal children.','6827','def-1874',1,1,1,2,2.00,5.00,'70999',35,'https://via.placeholder.com/200x200.png/00ff77?text=fuga',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(608,'Seven flung down his face.','9305','def-9072',2,1,1,3,10.00,7.00,'82823',80,'https://via.placeholder.com/200x200.png/00ee11?text=vero',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(609,'Cheshire Cat, she was as.','4655','def-4408',1,1,1,2,4.00,2.00,'16930',61,'https://via.placeholder.com/200x200.png/00cc66?text=nostrum',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(610,'I am in the sea, though you.','8613','def-5679',2,1,1,3,5.00,5.00,'35528',58,'https://via.placeholder.com/200x200.png/0088aa?text=ab',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(611,'The first question of course.','4618','def-3604',2,2,1,2,8.00,3.00,'82623',56,'https://via.placeholder.com/200x200.png/0022dd?text=quod',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(612,'Two. Two began in a hurry: a.','6282','def-9901',1,1,1,2,9.00,7.00,'52395',50,'https://via.placeholder.com/200x200.png/000077?text=accusantium',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(613,'Latitude was, or Longitude.','4213','def-2294',2,2,1,1,2.00,7.00,'97523',57,'https://via.placeholder.com/200x200.png/0033ee?text=cumque',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(614,'That\'s all.\' \'Thank you,\'.','4173','def-7359',1,1,1,1,6.00,6.00,'53817',78,'https://via.placeholder.com/200x200.png/004488?text=id',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(615,'Please, Ma\'am, is this New.','8289','def-4161',1,2,1,2,2.00,2.00,'58615',44,'https://via.placeholder.com/200x200.png/0044ff?text=accusantium',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(616,'Five! Don\'t go splashing.','8039','def-7338',2,2,1,3,7.00,10.00,'89596',71,'https://via.placeholder.com/200x200.png/002299?text=ducimus',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(617,'CHAPTER VI. Pig and Pepper.','2088','def-1332',1,2,1,1,5.00,5.00,'66139',36,'https://via.placeholder.com/200x200.png/003399?text=perspiciatis',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(618,'Gryphon. \'Turn a somersault.','2613','def-2368',2,1,1,2,3.00,4.00,'21951',60,'https://via.placeholder.com/200x200.png/000088?text=nobis',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(619,'Dodo replied very gravely.','8601','def-5746',1,1,1,1,1.00,9.00,'89884',37,'https://via.placeholder.com/200x200.png/00aaee?text=autem',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(620,'CHAPTER III. A Caucus-Race.','1063','def-2771',1,2,1,3,5.00,3.00,'49958',91,'https://via.placeholder.com/200x200.png/00aa77?text=repellat',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(621,'I think I may as well wait.','2352','def-4995',1,2,1,2,1.00,8.00,'5693',31,'https://via.placeholder.com/200x200.png/00dd11?text=consequatur',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(622,'King: \'leave out that it.','1286','def-8607',2,2,1,2,10.00,5.00,'31695',61,'https://via.placeholder.com/200x200.png/0011ff?text=consequatur',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(623,'Dormouse; \'VERY ill.\' Alice.','6582','def-1039',1,2,1,1,3.00,2.00,'99214',82,'https://via.placeholder.com/200x200.png/004411?text=aut',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(624,'Why, I do hope it\'ll make me.','9756','def-9186',1,2,1,1,8.00,4.00,'81950',71,'https://via.placeholder.com/200x200.png/005522?text=impedit',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(625,'Alice in a long, low hall.','4033','def-6001',1,1,1,2,7.00,4.00,'61088',55,'https://via.placeholder.com/200x200.png/007799?text=quam',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(626,'Shark, But, when the tide.','9392','def-1480',1,2,1,3,9.00,10.00,'5405',46,'https://via.placeholder.com/200x200.png/001199?text=qui',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(627,'As a duck with its mouth and.','9418','def-3485',2,2,1,1,10.00,10.00,'85622',35,'https://via.placeholder.com/200x200.png/0000ee?text=iusto',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(628,'And how odd the directions.','6845','def-7192',1,1,1,3,2.00,2.00,'10805',33,'https://via.placeholder.com/200x200.png/00cc11?text=fuga',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(629,'It quite makes my forehead.','4218','def-1917',1,2,1,3,10.00,5.00,'95067',54,'https://via.placeholder.com/200x200.png/00aaaa?text=eligendi',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(630,'But if I\'m Mabel, I\'ll stay.','3024','def-1230',1,2,1,1,7.00,10.00,'93426',67,'https://via.placeholder.com/200x200.png/00aaaa?text=debitis',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(631,'Prizes!\' Alice had been to.','7439','def-3254',2,1,1,3,9.00,10.00,'28909',99,'https://via.placeholder.com/200x200.png/00dd77?text=odit',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(632,'Alice; but she had tired.','4029','def-7879',2,2,1,2,6.00,7.00,'70890',87,'https://via.placeholder.com/200x200.png/002233?text=voluptate',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(633,'Footman continued in the.','9106','def-2762',1,2,1,3,3.00,8.00,'98928',86,'https://via.placeholder.com/200x200.png/00dd00?text=id',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(634,'However, the Multiplication.','6929','def-7636',2,1,1,3,8.00,4.00,'39188',33,'https://via.placeholder.com/200x200.png/0088aa?text=a',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(635,'Gryphon, \'she wants for to.','9044','def-1537',2,1,1,1,8.00,7.00,'97499',93,'https://via.placeholder.com/200x200.png/00aaff?text=exercitationem',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(636,'However, \'jury-men\' would.','8354','def-1297',1,1,1,3,9.00,9.00,'76975',67,'https://via.placeholder.com/200x200.png/00ddaa?text=reiciendis',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(637,'Queen in front of them, with.','5123','def-3127',1,2,1,1,2.00,3.00,'10142',29,'https://via.placeholder.com/200x200.png/006633?text=ut',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(638,'I was going off into a pig,\'.','4668','def-2396',1,2,1,1,7.00,10.00,'93991',93,'https://via.placeholder.com/200x200.png/0099cc?text=deserunt',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(639,'Because he knows it teases.\'.','9793','def-9315',2,2,1,3,3.00,1.00,'32671',86,'https://via.placeholder.com/200x200.png/008877?text=consequatur',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(640,'DOTH THE LITTLE BUSY BEE,\".','8081','def-1978',1,1,1,1,4.00,4.00,'32031',45,'https://via.placeholder.com/200x200.png/00ffbb?text=aut',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(641,'But her sister was reading.','4160','def-3387',2,2,1,2,3.00,6.00,'17682',54,'https://via.placeholder.com/200x200.png/00ff00?text=voluptate',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(642,'March Hare went \'Sh! sh!\'.','5818','def-4705',1,2,1,3,2.00,1.00,'40522',66,'https://via.placeholder.com/200x200.png/00dd99?text=exercitationem',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(643,'Mock Turtle, and to stand on.','4698','def-1870',1,2,1,2,1.00,3.00,'15822',29,'https://via.placeholder.com/200x200.png/001133?text=dolor',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(644,'Bill\'s got to the rose-tree.','3411','def-2588',1,1,1,1,2.00,9.00,'67273',91,'https://via.placeholder.com/200x200.png/006644?text=cum',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(645,'Alice, \'they\'re sure to make.','8162','def-5303',1,2,1,2,8.00,7.00,'47272',65,'https://via.placeholder.com/200x200.png/004488?text=qui',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(646,'Gryphon, with a deep sigh.','6562','def-3651',1,2,1,1,4.00,7.00,'94200',79,'https://via.placeholder.com/200x200.png/0066ee?text=rerum',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(647,'Dormouse. \'Write that down,\'.','2672','def-9524',1,2,1,3,10.00,10.00,'75522',98,'https://via.placeholder.com/200x200.png/006688?text=repellat',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(648,'I may as well as she could.','6594','def-9499',2,1,1,2,1.00,3.00,'83090',66,'https://via.placeholder.com/200x200.png/004466?text=natus',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(649,'COULD! I\'m sure _I_ shan\'t.','6087','def-2052',2,2,1,2,7.00,8.00,'69292',54,'https://via.placeholder.com/200x200.png/00ddbb?text=illum',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(650,'Cat. \'I said pig,\' replied.','7812','def-9918',2,2,1,2,3.00,3.00,'92748',95,'https://via.placeholder.com/200x200.png/0055bb?text=et',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(651,'Alice)--\'and perhaps you.','1219','def-8975',1,2,1,3,7.00,10.00,'95878',28,'https://via.placeholder.com/200x200.png/004499?text=a',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(652,'Queen, and Alice was very.','9658','def-4129',2,2,1,3,10.00,8.00,'57533',74,'https://via.placeholder.com/200x200.png/006611?text=iusto',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(653,'I breathe\"!\' \'It IS a long.','2709','def-9956',1,1,1,3,6.00,1.00,'96118',94,'https://via.placeholder.com/200x200.png/0066aa?text=laudantium',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(654,'Mouse in the wind, and was.','7851','def-1663',1,2,1,3,7.00,6.00,'1512',53,'https://via.placeholder.com/200x200.png/003388?text=rerum',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(655,'Alice cautiously replied.','2372','def-8172',1,1,1,1,3.00,6.00,'17104',90,'https://via.placeholder.com/200x200.png/00aadd?text=ea',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(656,'Alice. \'Well, I shan\'t go.','1412','def-4152',1,2,1,1,9.00,7.00,'97224',85,'https://via.placeholder.com/200x200.png/007711?text=facilis',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(657,'Rabbit say to itself, \'Oh.','2673','def-6844',1,1,1,3,5.00,9.00,'84685',68,'https://via.placeholder.com/200x200.png/005555?text=aut',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(658,'I to get to,\' said the Duck.','5639','def-6650',2,1,1,1,3.00,2.00,'42803',83,'https://via.placeholder.com/200x200.png/00aaff?text=aperiam',1,'System@email.com','2023-12-27 12:12:49','2023-12-27 12:12:49'),(659,'King, going up to the Knave.','7713','def-2487',2,1,1,3,8.00,9.00,'65817',52,'https://via.placeholder.com/200x200.png/00bb77?text=iusto',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(660,'Alice\'s head. \'Is that the.','4592','def-8500',1,2,1,1,3.00,5.00,'74571',43,'https://via.placeholder.com/200x200.png/00ffee?text=itaque',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(661,'CHORUS. \'Wow! wow! wow!\'.','6279','def-2184',2,2,1,3,9.00,4.00,'8190',53,'https://via.placeholder.com/200x200.png/000066?text=et',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(662,'I don\'t want to see if she.','7779','def-3446',2,2,1,3,1.00,4.00,'74721',50,'https://via.placeholder.com/200x200.png/0033ff?text=neque',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(663,'Pepper For a minute or two.','8021','def-9093',2,2,1,2,1.00,6.00,'64267',30,'https://via.placeholder.com/200x200.png/00dd55?text=harum',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(664,'Alice the moment how large.','6449','def-7296',2,2,1,3,8.00,7.00,'72178',32,'https://via.placeholder.com/200x200.png/00bb44?text=soluta',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(665,'Alice; \'you needn\'t be so.','4322','def-9657',1,1,1,1,10.00,8.00,'57902',60,'https://via.placeholder.com/200x200.png/006644?text=ullam',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(666,'I\'ve tried to curtsey as she.','1453','def-4594',1,2,1,1,3.00,10.00,'86868',75,'https://via.placeholder.com/200x200.png/0088dd?text=laudantium',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(667,'Pigeon the opportunity of.','1165','def-5491',2,2,1,1,1.00,6.00,'42952',61,'https://via.placeholder.com/200x200.png/00dd00?text=voluptas',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(668,'Gryphon, and, taking Alice.','2886','def-4406',1,1,1,3,3.00,10.00,'63913',92,'https://via.placeholder.com/200x200.png/008844?text=vitae',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(669,'I\'ve said as yet.\' \'A cheap.','3597','def-9082',1,1,1,1,6.00,1.00,'74236',69,'https://via.placeholder.com/200x200.png/00aa66?text=harum',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(670,'Dinah, tell me who YOU are.','4268','def-3796',1,2,1,2,3.00,9.00,'26208',45,'https://via.placeholder.com/200x200.png/00aa33?text=adipisci',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(671,'IS it to annoy, Because he.','2845','def-3673',2,1,1,1,5.00,5.00,'76295',52,'https://via.placeholder.com/200x200.png/00ddcc?text=ut',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(672,'Hatter trembled so, that he.','4906','def-5663',2,2,1,3,9.00,7.00,'76653',44,'https://via.placeholder.com/200x200.png/004433?text=libero',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(673,'Alice felt a very pretty.','2303','def-5696',1,1,1,3,6.00,1.00,'24504',84,'https://via.placeholder.com/200x200.png/0066ff?text=ut',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(674,'She was looking at it again.','4383','def-2547',1,1,1,2,4.00,5.00,'72168',96,'https://via.placeholder.com/200x200.png/002211?text=in',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(675,'Alice, looking down with her.','1740','def-1112',2,1,1,3,4.00,2.00,'80769',59,'https://via.placeholder.com/200x200.png/0077dd?text=necessitatibus',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(676,'Alice \'without pictures or.','5303','def-7251',2,1,1,1,3.00,5.00,'10024',47,'https://via.placeholder.com/200x200.png/0000ee?text=error',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(677,'Queen, the royal children.','8492','def-7107',1,1,1,2,7.00,9.00,'71525',46,'https://via.placeholder.com/200x200.png/0044cc?text=neque',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(678,'Shakespeare, in the face.','7828','def-9368',2,1,1,2,1.00,4.00,'38952',25,'https://via.placeholder.com/200x200.png/00cc55?text=eveniet',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(679,'Still she went back to the.','8703','def-5615',2,2,1,3,3.00,3.00,'22909',87,'https://via.placeholder.com/200x200.png/005577?text=consequatur',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(680,'The further off from England.','6230','def-2593',1,1,1,3,10.00,7.00,'59788',52,'https://via.placeholder.com/200x200.png/007777?text=blanditiis',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(681,'Sir, With no jury or judge.','2395','def-4416',2,2,1,2,8.00,5.00,'54057',29,'https://via.placeholder.com/200x200.png/00ddbb?text=aperiam',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(682,'There was a queer-shaped.','7754','def-8013',2,1,1,2,6.00,9.00,'8583',36,'https://via.placeholder.com/200x200.png/009922?text=veritatis',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(683,'Cat. \'I\'d nearly forgotten.','1884','def-8180',2,2,1,1,10.00,3.00,'29914',61,'https://via.placeholder.com/200x200.png/005577?text=nemo',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(684,'The soldiers were always.','2332','def-4882',1,1,1,1,4.00,6.00,'76788',36,'https://via.placeholder.com/200x200.png/00aaaa?text=natus',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(685,'ALL PERSONS MORE THAN A MILE.','3741','def-1886',1,2,1,3,6.00,9.00,'17546',26,'https://via.placeholder.com/200x200.png/00ffaa?text=rem',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(686,'Alice; \'I must be a great.','8444','def-1107',1,2,1,2,2.00,8.00,'32733',87,'https://via.placeholder.com/200x200.png/007755?text=aliquam',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(687,'Dormouse turned out, and, by.','2879','def-6994',2,2,1,2,9.00,5.00,'60467',67,'https://via.placeholder.com/200x200.png/00aa88?text=impedit',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(688,'Dormouse is asleep again,\'.','8278','def-6528',1,2,1,1,10.00,10.00,'4300',62,'https://via.placeholder.com/200x200.png/0011ff?text=neque',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(689,'Then turn not pale, beloved.','8404','def-3643',1,1,1,1,8.00,5.00,'98023',94,'https://via.placeholder.com/200x200.png/00ccff?text=ut',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(690,'I never knew whether it was.','9537','def-8134',1,1,1,1,9.00,2.00,'12302',25,'https://via.placeholder.com/200x200.png/004422?text=asperiores',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(691,'But she did not notice this.','2732','def-9332',1,2,1,1,6.00,6.00,'33064',74,'https://via.placeholder.com/200x200.png/008888?text=autem',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(692,'March Hare. \'Sixteenth,\'.','5792','def-8172',1,1,1,2,10.00,3.00,'5055',75,'https://via.placeholder.com/200x200.png/001111?text=eos',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(693,'Alice a little bottle that.','5727','def-2102',1,2,1,3,10.00,7.00,'7277',27,'https://via.placeholder.com/200x200.png/00aadd?text=odio',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(694,'ARE OLD, FATHER WILLIAM,\' to.','8643','def-2818',1,1,1,2,1.00,2.00,'68960',59,'https://via.placeholder.com/200x200.png/0022aa?text=delectus',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(695,'Alice, quite forgetting that.','3633','def-9657',1,2,1,3,7.00,10.00,'88026',44,'https://via.placeholder.com/200x200.png/007777?text=ad',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(696,'Mock Turtle went on, half to.','7470','def-9884',1,1,1,2,5.00,4.00,'18862',43,'https://via.placeholder.com/200x200.png/00aabb?text=explicabo',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(697,'ALL RETURNED FROM HIM TO.','7030','def-5768',1,1,1,1,3.00,7.00,'32334',23,'https://via.placeholder.com/200x200.png/007744?text=quia',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(698,'Alice quietly said, just as.','2959','def-9224',1,2,1,1,2.00,8.00,'11077',40,'https://via.placeholder.com/200x200.png/0088ff?text=quis',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(699,'It\'s HIM.\' \'I don\'t quite.','9565','def-7246',2,2,1,1,8.00,6.00,'24091',27,'https://via.placeholder.com/200x200.png/000077?text=assumenda',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50'),(700,'She hastily put down the.','2276','def-8653',2,1,1,3,2.00,9.00,'3061',80,'https://via.placeholder.com/200x200.png/00ddcc?text=ipsam',1,'System@email.com','2023-12-27 12:12:50','2023-12-27 12:12:50');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchaseorders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchaseorders` (
  `purchaseOrderID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchaseID` bigint unsigned NOT NULL,
  `productID` bigint unsigned NOT NULL,
  `warehouseID` bigint unsigned NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `batchNumber` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiryDate` date DEFAULT NULL,
  `netUnitCost` double(8,2) unsigned NOT NULL,
  `discount` double(8,2) unsigned DEFAULT NULL,
  `tax` double(8,2) unsigned DEFAULT NULL,
  `subTotal` double(10,2) unsigned NOT NULL,
  `purchaseUnit` bigint unsigned NOT NULL,
  `date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`purchaseOrderID`),
  KEY `purchaseorders_purchaseid_foreign` (`purchaseID`),
  KEY `purchaseorders_productid_foreign` (`productID`),
  KEY `purchaseorders_warehouseid_foreign` (`warehouseID`),
  KEY `purchaseorders_purchaseunit_foreign` (`purchaseUnit`),
  CONSTRAINT `purchaseorders_productid_foreign` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`),
  CONSTRAINT `purchaseorders_purchaseid_foreign` FOREIGN KEY (`purchaseID`) REFERENCES `purchases` (`purchaseID`),
  CONSTRAINT `purchaseorders_purchaseunit_foreign` FOREIGN KEY (`purchaseUnit`) REFERENCES `units` (`unitID`),
  CONSTRAINT `purchaseorders_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchaseorders` WRITE;
/*!40000 ALTER TABLE `purchaseorders` DISABLE KEYS */;
INSERT INTO `purchaseorders` VALUES (1,1,694,1,'8643',2,'def-2818',NULL,5600.00,0.00,0.00,11200.00,2,'2023-12-27','2023-12-27 12:13:14','2023-12-27 12:13:14','owner@email.com'),(2,1,698,1,'2959',1,'def-9224',NULL,5467.00,0.00,0.00,5467.00,1,'2023-12-27','2023-12-27 12:13:14','2023-12-27 12:13:14','owner@email.com');
/*!40000 ALTER TABLE `purchaseorders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchasepayments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchasepayments` (
  `purchasePaymentID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchaseID` bigint unsigned NOT NULL,
  `accountID` bigint unsigned NOT NULL,
  `warehouseID` bigint unsigned NOT NULL,
  `amount` double(10,2) unsigned NOT NULL,
  `date` date NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refID` int NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`purchasePaymentID`),
  KEY `purchasepayments_purchaseid_foreign` (`purchaseID`),
  KEY `purchasepayments_accountid_foreign` (`accountID`),
  KEY `purchasepayments_warehouseid_foreign` (`warehouseID`),
  CONSTRAINT `purchasepayments_accountid_foreign` FOREIGN KEY (`accountID`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `purchasepayments_purchaseid_foreign` FOREIGN KEY (`purchaseID`) REFERENCES `purchases` (`purchaseID`),
  CONSTRAINT `purchasepayments_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchasepayments` WRITE;
/*!40000 ALTER TABLE `purchasepayments` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchasepayments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchasereceives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchasereceives` (
  `purchaseReceiveID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchaseID` bigint unsigned NOT NULL,
  `productID` bigint unsigned NOT NULL,
  `batchNumber` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiryDate` date DEFAULT NULL,
  `orderedQty` int DEFAULT NULL,
  `receivedQty` int DEFAULT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `refID` int NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`purchaseReceiveID`),
  KEY `purchasereceives_purchaseid_foreign` (`purchaseID`),
  KEY `purchasereceives_productid_foreign` (`productID`),
  CONSTRAINT `purchasereceives_productid_foreign` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`),
  CONSTRAINT `purchasereceives_purchaseid_foreign` FOREIGN KEY (`purchaseID`) REFERENCES `purchases` (`purchaseID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchasereceives` WRITE;
/*!40000 ALTER TABLE `purchasereceives` DISABLE KEYS */;
INSERT INTO `purchasereceives` VALUES (1,1,694,'def-2818',NULL,2,NULL,NULL,1,'owner@email.com'),(2,1,694,'def-2818',NULL,NULL,2,NULL,1,'owner@email.com'),(3,1,698,'def-9224',NULL,1,NULL,NULL,1,'owner@email.com'),(4,1,698,'def-9224',NULL,NULL,1,NULL,1,'owner@email.com');
/*!40000 ALTER TABLE `purchasereceives` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchasereturndetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchasereturndetails` (
  `purchaseReturnDetailID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchaseReturnID` bigint unsigned NOT NULL,
  `productID` bigint unsigned NOT NULL,
  `batchNumber` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `returnQuantity` int NOT NULL,
  `expiryDate` date DEFAULT NULL,
  `deductionAmount` double(8,2) unsigned DEFAULT NULL,
  `subTotal` double(10,2) unsigned NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refID` int NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`purchaseReturnDetailID`),
  KEY `purchasereturndetails_purchasereturnid_foreign` (`purchaseReturnID`),
  KEY `purchasereturndetails_productid_foreign` (`productID`),
  CONSTRAINT `purchasereturndetails_productid_foreign` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`),
  CONSTRAINT `purchasereturndetails_purchasereturnid_foreign` FOREIGN KEY (`purchaseReturnID`) REFERENCES `purchasereturns` (`purchaseReturnID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchasereturndetails` WRITE;
/*!40000 ALTER TABLE `purchasereturndetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchasereturndetails` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchasereturnpayments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchasereturnpayments` (
  `purchaseReturnPaymentID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchaseReturnID` bigint unsigned NOT NULL,
  `accountID` bigint unsigned NOT NULL,
  `amount` double(10,2) unsigned NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refID` int NOT NULL,
  `date` date NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`purchaseReturnPaymentID`),
  KEY `purchasereturnpayments_purchasereturnid_foreign` (`purchaseReturnID`),
  KEY `purchasereturnpayments_accountid_foreign` (`accountID`),
  CONSTRAINT `purchasereturnpayments_accountid_foreign` FOREIGN KEY (`accountID`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `purchasereturnpayments_purchasereturnid_foreign` FOREIGN KEY (`purchaseReturnID`) REFERENCES `purchasereturns` (`purchaseReturnID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchasereturnpayments` WRITE;
/*!40000 ALTER TABLE `purchasereturnpayments` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchasereturnpayments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchasereturns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchasereturns` (
  `purchaseReturnID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchaseID` bigint unsigned NOT NULL,
  `accountID` bigint unsigned DEFAULT NULL,
  `supplierID` bigint unsigned NOT NULL,
  `warehouseID` bigint unsigned NOT NULL,
  `amount` double(10,2) unsigned DEFAULT NULL,
  `shippingCost` double(8,2) unsigned DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refID` int NOT NULL,
  PRIMARY KEY (`purchaseReturnID`),
  KEY `purchasereturns_purchaseid_foreign` (`purchaseID`),
  KEY `purchasereturns_accountid_foreign` (`accountID`),
  KEY `purchasereturns_supplierid_foreign` (`supplierID`),
  KEY `purchasereturns_warehouseid_foreign` (`warehouseID`),
  CONSTRAINT `purchasereturns_accountid_foreign` FOREIGN KEY (`accountID`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `purchasereturns_purchaseid_foreign` FOREIGN KEY (`purchaseID`) REFERENCES `purchases` (`purchaseID`),
  CONSTRAINT `purchasereturns_supplierid_foreign` FOREIGN KEY (`supplierID`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `purchasereturns_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchasereturns` WRITE;
/*!40000 ALTER TABLE `purchasereturns` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchasereturns` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchases` (
  `purchaseID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `supplierID` bigint unsigned NOT NULL,
  `warehouseID` bigint unsigned NOT NULL,
  `purchaseStatus` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orderTax` double(8,2) unsigned DEFAULT NULL,
  `discount` double(8,2) unsigned DEFAULT NULL,
  `shippingCost` double(8,2) unsigned DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `refID` int NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`purchaseID`),
  KEY `purchases_supplierid_foreign` (`supplierID`),
  KEY `purchases_warehouseid_foreign` (`warehouseID`),
  CONSTRAINT `purchases_supplierid_foreign` FOREIGN KEY (`supplierID`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `purchases_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchases` WRITE;
/*!40000 ALTER TABLE `purchases` DISABLE KEYS */;
INSERT INTO `purchases` VALUES (1,5,1,'received',NULL,0.00,0.00,0.00,NULL,'2023-12-27',1,'owner@email.com','2023-12-27 12:13:14','2023-12-27 12:13:14');
/*!40000 ALTER TABLE `purchases` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchasestatuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchasestatuses` (
  `purchaseStatusID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`purchaseStatusID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchasestatuses` WRITE;
/*!40000 ALTER TABLE `purchasestatuses` DISABLE KEYS */;
INSERT INTO `purchasestatuses` VALUES (1,'Received',NULL,NULL,NULL),(2,'Partial',NULL,NULL,NULL),(3,'Pending',NULL,NULL,NULL),(4,'Ordered',NULL,NULL,NULL);
/*!40000 ALTER TABLE `purchasestatuses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `quotation_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotation_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `quotationID` bigint unsigned NOT NULL,
  `productID` bigint unsigned NOT NULL,
  `discount` double(8,2) unsigned DEFAULT NULL,
  `tax` double(8,2) unsigned DEFAULT NULL,
  `price` double(8,2) unsigned NOT NULL,
  `qty` double(8,2) unsigned NOT NULL,
  `net` double(8,2) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quotation_details_quotationid_foreign` (`quotationID`),
  KEY `quotation_details_productid_foreign` (`productID`),
  CONSTRAINT `quotation_details_productid_foreign` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`),
  CONSTRAINT `quotation_details_quotationid_foreign` FOREIGN KEY (`quotationID`) REFERENCES `quotations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `quotation_details` WRITE;
/*!40000 ALTER TABLE `quotation_details` DISABLE KEYS */;
INSERT INTO `quotation_details` VALUES (1,1,2,0.00,0.00,345.00,2.00,690.00,'2023-12-29 08:58:56','2023-12-29 08:58:56');
/*!40000 ALTER TABLE `quotation_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `quotations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `date` date NOT NULL,
  `warehouseID` bigint unsigned NOT NULL,
  `shipping` double(8,2) unsigned DEFAULT NULL,
  `discount` double(8,2) unsigned DEFAULT NULL,
  `tax` double(8,2) unsigned DEFAULT NULL,
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quotations_warehouseid_foreign` (`warehouseID`),
  CONSTRAINT `quotations_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `quotations` WRITE;
/*!40000 ALTER TABLE `quotations` DISABLE KEYS */;
INSERT INTO `quotations` VALUES (1,'Abas Khan',NULL,NULL,'2023-12-29',1,0.00,0.00,0.00,NULL,'owner@email.com','2023-12-29 08:58:56','2023-12-29 08:58:56');
/*!40000 ALTER TABLE `quotations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reconditioneds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reconditioneds` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `obsoleteID` bigint unsigned NOT NULL,
  `productID` bigint unsigned NOT NULL,
  `warehouseID` bigint unsigned NOT NULL,
  `date` date NOT NULL,
  `batchNumber` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiry` date DEFAULT NULL,
  `quantity` double(8,2) unsigned NOT NULL,
  `expense` double(8,2) unsigned NOT NULL,
  `accountID` bigint unsigned NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `refID` int NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reconditioneds_obsoleteid_foreign` (`obsoleteID`),
  KEY `reconditioneds_productid_foreign` (`productID`),
  KEY `reconditioneds_warehouseid_foreign` (`warehouseID`),
  KEY `reconditioneds_accountid_foreign` (`accountID`),
  CONSTRAINT `reconditioneds_accountid_foreign` FOREIGN KEY (`accountID`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `reconditioneds_obsoleteid_foreign` FOREIGN KEY (`obsoleteID`) REFERENCES `obsoletes` (`id`),
  CONSTRAINT `reconditioneds_productid_foreign` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`),
  CONSTRAINT `reconditioneds_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reconditioneds` WRITE;
/*!40000 ALTER TABLE `reconditioneds` DISABLE KEYS */;
/*!40000 ALTER TABLE `reconditioneds` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `references`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `references` (
  `refID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ref` int NOT NULL,
  PRIMARY KEY (`refID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `references` WRITE;
/*!40000 ALTER TABLE `references` DISABLE KEYS */;
INSERT INTO `references` VALUES (1,5);
/*!40000 ALTER TABLE `references` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `repair_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repair_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `repairID` bigint unsigned NOT NULL,
  `accountID` bigint unsigned NOT NULL,
  `amount` double(8,2) NOT NULL,
  `date` date NOT NULL,
  `refID` int NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `repair_payments_repairid_foreign` (`repairID`),
  KEY `repair_payments_accountid_foreign` (`accountID`),
  CONSTRAINT `repair_payments_accountid_foreign` FOREIGN KEY (`accountID`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `repair_payments_repairid_foreign` FOREIGN KEY (`repairID`) REFERENCES `repairs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `repair_payments` WRITE;
/*!40000 ALTER TABLE `repair_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `repair_payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `repairs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repairs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `warehouseID` bigint unsigned NOT NULL,
  `customerName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accessories` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fault` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `charges` double(8,2) NOT NULL,
  `date` date NOT NULL,
  `returnDate` date NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `repairs_warehouseid_foreign` (`warehouseID`),
  CONSTRAINT `repairs_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `repairs` WRITE;
/*!40000 ALTER TABLE `repairs` DISABLE KEYS */;
/*!40000 ALTER TABLE `repairs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(21,1),(22,1),(23,1),(24,1),(25,1),(26,1),(27,1),(28,1),(29,1),(30,1),(31,1),(32,1),(33,1),(34,1),(35,1),(36,1),(37,1),(38,1),(39,1),(40,1),(41,1),(42,1),(43,1),(44,1),(45,1),(46,1),(47,1),(48,1),(49,1),(50,1),(51,1),(52,1),(53,1),(54,1),(55,1),(56,1),(57,1),(58,1),(59,1),(60,1),(61,1),(62,1),(63,1),(64,1),(65,1),(66,1),(67,1),(68,1),(69,1),(70,1);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Owner','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(2,'Admin','web','2023-12-27 12:12:41','2023-12-27 12:12:41'),(3,'Cashier','web','2023-12-27 12:12:41','2023-12-27 12:12:41');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `saledelivered`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `saledelivered` (
  `saleDeliveredID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `saleID` bigint unsigned NOT NULL,
  `productID` bigint unsigned NOT NULL,
  `batchNumber` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiryDate` date DEFAULT NULL,
  `orderedQty` int DEFAULT NULL,
  `receivedQty` int DEFAULT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `saleUnit` bigint unsigned NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`saleDeliveredID`),
  KEY `saledelivered_saleid_foreign` (`saleID`),
  KEY `saledelivered_productid_foreign` (`productID`),
  KEY `saledelivered_saleunit_foreign` (`saleUnit`),
  CONSTRAINT `saledelivered_productid_foreign` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`),
  CONSTRAINT `saledelivered_saleid_foreign` FOREIGN KEY (`saleID`) REFERENCES `sales` (`saleID`),
  CONSTRAINT `saledelivered_saleunit_foreign` FOREIGN KEY (`saleUnit`) REFERENCES `units` (`unitID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `saledelivered` WRITE;
/*!40000 ALTER TABLE `saledelivered` DISABLE KEYS */;
/*!40000 ALTER TABLE `saledelivered` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `saleorders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `saleorders` (
  `saleOrderID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `saleID` bigint unsigned NOT NULL,
  `productID` bigint unsigned NOT NULL,
  `warehouseID` bigint unsigned NOT NULL,
  `quantity` int NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batchNumber` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiryDate` date DEFAULT NULL,
  `netUnitCost` double(8,2) unsigned NOT NULL,
  `discountValue` double(8,2) unsigned DEFAULT NULL,
  `tax` double(8,2) unsigned DEFAULT NULL,
  `subTotal` double(10,2) unsigned NOT NULL,
  `saleUnit` bigint unsigned NOT NULL,
  `salesManID` bigint unsigned NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`saleOrderID`),
  KEY `saleorders_saleid_foreign` (`saleID`),
  KEY `saleorders_productid_foreign` (`productID`),
  KEY `saleorders_warehouseid_foreign` (`warehouseID`),
  KEY `saleorders_saleunit_foreign` (`saleUnit`),
  KEY `saleorders_salesmanid_foreign` (`salesManID`),
  CONSTRAINT `saleorders_productid_foreign` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`),
  CONSTRAINT `saleorders_saleid_foreign` FOREIGN KEY (`saleID`) REFERENCES `sales` (`saleID`),
  CONSTRAINT `saleorders_salesmanid_foreign` FOREIGN KEY (`salesManID`) REFERENCES `employees` (`id`),
  CONSTRAINT `saleorders_saleunit_foreign` FOREIGN KEY (`saleUnit`) REFERENCES `units` (`unitID`),
  CONSTRAINT `saleorders_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `saleorders` WRITE;
/*!40000 ALTER TABLE `saleorders` DISABLE KEYS */;
/*!40000 ALTER TABLE `saleorders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `salepayments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salepayments` (
  `salePaymentID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `saleID` bigint unsigned NOT NULL,
  `accountID` bigint unsigned NOT NULL,
  `amount` double(10,2) unsigned NOT NULL,
  `date` date NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refID` int NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`salePaymentID`),
  KEY `salepayments_saleid_foreign` (`saleID`),
  KEY `salepayments_accountid_foreign` (`accountID`),
  CONSTRAINT `salepayments_accountid_foreign` FOREIGN KEY (`accountID`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `salepayments_saleid_foreign` FOREIGN KEY (`saleID`) REFERENCES `sales` (`saleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `salepayments` WRITE;
/*!40000 ALTER TABLE `salepayments` DISABLE KEYS */;
/*!40000 ALTER TABLE `salepayments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `salereturndetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salereturndetails` (
  `saleReturnDetailID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `saleReturnID` bigint unsigned NOT NULL,
  `productID` bigint unsigned NOT NULL,
  `batchNumber` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `returnQuantity` int NOT NULL,
  `expiryDate` date DEFAULT NULL,
  `deductionAmount` double(8,2) unsigned DEFAULT NULL,
  `subTotal` double(10,2) unsigned NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refID` int NOT NULL,
  `salesManID` bigint unsigned NOT NULL,
  `commission` double(10,2) DEFAULT NULL,
  `date` date NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`saleReturnDetailID`),
  KEY `salereturndetails_salereturnid_foreign` (`saleReturnID`),
  KEY `salereturndetails_productid_foreign` (`productID`),
  KEY `salereturndetails_salesmanid_foreign` (`salesManID`),
  CONSTRAINT `salereturndetails_productid_foreign` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`),
  CONSTRAINT `salereturndetails_salereturnid_foreign` FOREIGN KEY (`saleReturnID`) REFERENCES `salereturns` (`saleReturnID`),
  CONSTRAINT `salereturndetails_salesmanid_foreign` FOREIGN KEY (`salesManID`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `salereturndetails` WRITE;
/*!40000 ALTER TABLE `salereturndetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `salereturndetails` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `salereturnpayments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salereturnpayments` (
  `saleReturnPaymentID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `saleReturnID` bigint unsigned NOT NULL,
  `accountID` bigint unsigned NOT NULL,
  `amount` double(10,2) unsigned NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refID` int NOT NULL,
  `date` date NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`saleReturnPaymentID`),
  KEY `salereturnpayments_salereturnid_foreign` (`saleReturnID`),
  KEY `salereturnpayments_accountid_foreign` (`accountID`),
  CONSTRAINT `salereturnpayments_accountid_foreign` FOREIGN KEY (`accountID`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `salereturnpayments_salereturnid_foreign` FOREIGN KEY (`saleReturnID`) REFERENCES `salereturns` (`saleReturnID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `salereturnpayments` WRITE;
/*!40000 ALTER TABLE `salereturnpayments` DISABLE KEYS */;
/*!40000 ALTER TABLE `salereturnpayments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `salereturns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salereturns` (
  `saleReturnID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `saleID` bigint unsigned NOT NULL,
  `accountID` bigint unsigned DEFAULT NULL,
  `customerID` bigint unsigned NOT NULL,
  `warehouseID` bigint unsigned NOT NULL,
  `amount` double(10,2) unsigned DEFAULT NULL,
  `shippingCost` int DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `refID` int NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`saleReturnID`),
  KEY `salereturns_saleid_foreign` (`saleID`),
  KEY `salereturns_accountid_foreign` (`accountID`),
  KEY `salereturns_customerid_foreign` (`customerID`),
  KEY `salereturns_warehouseid_foreign` (`warehouseID`),
  CONSTRAINT `salereturns_accountid_foreign` FOREIGN KEY (`accountID`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `salereturns_customerid_foreign` FOREIGN KEY (`customerID`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `salereturns_saleid_foreign` FOREIGN KEY (`saleID`) REFERENCES `sales` (`saleID`),
  CONSTRAINT `salereturns_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `salereturns` WRITE;
/*!40000 ALTER TABLE `salereturns` DISABLE KEYS */;
/*!40000 ALTER TABLE `salereturns` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `saleID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customerID` bigint unsigned NOT NULL,
  `warehouseID` bigint unsigned NOT NULL,
  `salesManID` bigint unsigned NOT NULL,
  `saleStatus` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referenceNo` int DEFAULT NULL,
  `shippingCost` double(8,2) unsigned DEFAULT NULL,
  `discountValue` double(8,2) unsigned DEFAULT NULL,
  `orderTax` double(8,2) unsigned DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `points` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orderDiscountType` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refID` int NOT NULL,
  `date` date NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`saleID`),
  KEY `sales_customerid_foreign` (`customerID`),
  KEY `sales_warehouseid_foreign` (`warehouseID`),
  KEY `sales_salesmanid_foreign` (`salesManID`),
  CONSTRAINT `sales_customerid_foreign` FOREIGN KEY (`customerID`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `sales_salesmanid_foreign` FOREIGN KEY (`salesManID`) REFERENCES `employees` (`id`),
  CONSTRAINT `sales_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stock_transfer_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_transfer_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `transferID` bigint unsigned NOT NULL,
  `productID` bigint unsigned NOT NULL,
  `batchNumber` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiryDate` date DEFAULT NULL,
  `qty` double(8,2) DEFAULT NULL,
  `refID` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_transfer_details_transferid_foreign` (`transferID`),
  KEY `stock_transfer_details_productid_foreign` (`productID`),
  CONSTRAINT `stock_transfer_details_productid_foreign` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`),
  CONSTRAINT `stock_transfer_details_transferid_foreign` FOREIGN KEY (`transferID`) REFERENCES `stock_transfers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stock_transfer_details` WRITE;
/*!40000 ALTER TABLE `stock_transfer_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_transfer_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stock_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_transfers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `from` bigint unsigned NOT NULL,
  `to` bigint unsigned NOT NULL,
  `accountID` bigint unsigned NOT NULL,
  `expense` int NOT NULL,
  `date` date NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refID` int NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `acceptedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_transfers_from_foreign` (`from`),
  KEY `stock_transfers_to_foreign` (`to`),
  KEY `stock_transfers_accountid_foreign` (`accountID`),
  CONSTRAINT `stock_transfers_accountid_foreign` FOREIGN KEY (`accountID`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `stock_transfers_from_foreign` FOREIGN KEY (`from`) REFERENCES `warehouses` (`warehouseID`),
  CONSTRAINT `stock_transfers_to_foreign` FOREIGN KEY (`to`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stock_transfers` WRITE;
/*!40000 ALTER TABLE `stock_transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_transfers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stocks` (
  `stockID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `warehouseID` bigint unsigned NOT NULL,
  `productID` bigint unsigned NOT NULL,
  `batchNumber` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiryDate` date DEFAULT NULL,
  `date` date DEFAULT NULL,
  `credit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refID` int NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`stockID`),
  KEY `stocks_warehouseid_foreign` (`warehouseID`),
  KEY `stocks_productid_foreign` (`productID`),
  CONSTRAINT `stocks_productid_foreign` FOREIGN KEY (`productID`) REFERENCES `products` (`productID`),
  CONSTRAINT `stocks_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stocks` WRITE;
/*!40000 ALTER TABLE `stocks` DISABLE KEYS */;
INSERT INTO `stocks` VALUES (1,1,694,'def-2818',NULL,'2023-12-27','2',NULL,1,NULL,'2023-12-27 12:13:14','2023-12-27 12:13:14','owner@email.com'),(2,1,698,'def-9224',NULL,'2023-12-27','1',NULL,1,NULL,'2023-12-27 12:13:14','2023-12-27 12:13:14','owner@email.com'),(3,1,694,'def-2818',NULL,'2023-12-27',NULL,'1',2,'Moved to obsolete inventory with the reason: ytyutytyutuy','2023-12-27 12:13:40','2023-12-27 12:22:00','owner@email.com');
/*!40000 ALTER TABLE `stocks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `targets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `targets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `startDate` date NOT NULL,
  `endDate` date NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `targets` WRITE;
/*!40000 ALTER TABLE `targets` DISABLE KEYS */;
/*!40000 ALTER TABLE `targets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `todos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `todos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `due` date NOT NULL,
  `warehouseID` bigint unsigned NOT NULL,
  `refID` int NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `todos_warehouseid_foreign` (`warehouseID`),
  CONSTRAINT `todos_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `todos` WRITE;
/*!40000 ALTER TABLE `todos` DISABLE KEYS */;
/*!40000 ALTER TABLE `todos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `transactionID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `accountID` bigint unsigned NOT NULL,
  `date` date NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `credit` double(10,2) unsigned DEFAULT NULL,
  `debt` double(10,2) unsigned DEFAULT NULL,
  `refID` int NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`transactionID`),
  KEY `transactions_accountid_foreign` (`accountID`),
  CONSTRAINT `transactions_accountid_foreign` FOREIGN KEY (`accountID`) REFERENCES `accounts` (`accountID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,5,'2023-12-27','Purchase',16667.00,0.00,1,'<b>Purchase</b><br> Pending Amount of Purchase #1','2023-12-27 12:13:14','2023-12-27 12:13:14','owner@email.com'),(2,2,'2023-12-27','Obsolete Recovery',NULL,0.00,2,'Recovery of Obsolete Recovery','2023-12-27 12:13:40','2023-12-27 12:22:00','owner@email.com'),(3,2,'2023-12-29','Deposit',200.00,0.00,3,NULL,'2023-12-29 09:02:00','2023-12-29 09:02:00','owner@email.com'),(4,2,'2023-12-29','Expense',0.00,243.00,5,NULL,'2023-12-29 09:04:14','2023-12-29 09:04:14','owner@email.com');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `units` (
  `unitID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` int NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`unitID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (1,'1 in box',5,'System','2023-12-27 12:12:44','2023-12-29 09:16:02'),(2,'2 in box',2,'System','2023-12-27 12:12:44','2023-12-27 12:12:44'),(3,'10 in box',10,'System','2023-12-27 12:12:44','2023-12-27 12:12:44');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `warehouseID` bigint unsigned NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_warehouseid_foreign` (`warehouseID`),
  CONSTRAINT `users_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Owner','owner@email.com',1,NULL,'$2y$10$hfjN5gCyBRrbAWULZR2lw.GGJ0JlZXfiORqYvsVABcdf6HHC/eEga',NULL,'System','2023-12-27 12:12:44','2023-12-27 12:12:44'),(2,'Admin','admin@email.com',1,NULL,'$2y$10$.gvSVSL.lopFO2mHpX2nuOglbBuySBxxIwEYIpR0nq3t48712Y6JO',NULL,'System','2023-12-27 12:12:44','2023-12-27 12:12:44'),(3,'Cashier','cashier@email.com',2,NULL,'$2y$10$zXAUVV6lf7apyW0boJ0xs.abu60MdXAdocgVDHbfsMOoTVkJowaX.',NULL,'System','2023-12-27 12:12:44','2023-12-27 12:12:44');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `visits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `warehouseID` bigint unsigned NOT NULL,
  `visit_by` bigint unsigned NOT NULL,
  `visit_to` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `exp` bigint NOT NULL DEFAULT '0',
  `account` bigint unsigned NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `refID` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `visits_warehouseid_foreign` (`warehouseID`),
  KEY `visits_visit_by_foreign` (`visit_by`),
  KEY `visits_account_foreign` (`account`),
  CONSTRAINT `visits_account_foreign` FOREIGN KEY (`account`) REFERENCES `accounts` (`accountID`),
  CONSTRAINT `visits_visit_by_foreign` FOREIGN KEY (`visit_by`) REFERENCES `employees` (`id`),
  CONSTRAINT `visits_warehouseid_foreign` FOREIGN KEY (`warehouseID`) REFERENCES `warehouses` (`warehouseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `visits` WRITE;
/*!40000 ALTER TABLE `visits` DISABLE KEYS */;
/*!40000 ALTER TABLE `visits` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `warehouses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouses` (
  `warehouseID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` text COLLATE utf8mb4_unicode_ci,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`warehouseID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `warehouses` WRITE;
/*!40000 ALTER TABLE `warehouses` DISABLE KEYS */;
INSERT INTO `warehouses` VALUES (1,'Main Warehouse',NULL,NULL,NULL,NULL,'System','2023-12-27 12:12:43','2023-12-27 12:12:43'),(2,'Warehouse 2',NULL,NULL,NULL,NULL,'System','2023-12-27 12:12:43','2023-12-27 12:12:43');
/*!40000 ALTER TABLE `warehouses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `withdrawaldeposits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `withdrawaldeposits` (
  `withdrawalDepositID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `accountID` bigint unsigned NOT NULL,
  `paymentType` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(10,2) unsigned NOT NULL,
  `date` date NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refID` int NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`withdrawalDepositID`),
  KEY `withdrawaldeposits_accountid_foreign` (`accountID`),
  CONSTRAINT `withdrawaldeposits_accountid_foreign` FOREIGN KEY (`accountID`) REFERENCES `accounts` (`accountID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `withdrawaldeposits` WRITE;
/*!40000 ALTER TABLE `withdrawaldeposits` DISABLE KEYS */;
INSERT INTO `withdrawaldeposits` VALUES (1,2,'Deposit',200.00,'2023-12-29',NULL,3,'owner@email.com','2023-12-29 09:02:00','2023-12-29 09:02:00');
/*!40000 ALTER TABLE `withdrawaldeposits` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

